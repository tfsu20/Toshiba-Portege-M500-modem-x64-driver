@echo off
setlocal
net session >nul 2>&1
if not "%errorlevel%"=="0" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo Restarting the modem device to clear a stuck voice session...
pnputil /restart-device "HDAUDIO\FUNC_02&VEN_11C1&DEV_3026&SUBSYS_11790001&REV_1007\4&6CD3CC1&0&0101"
echo Done.
pause
