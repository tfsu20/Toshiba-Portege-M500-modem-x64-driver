<#
    ModemAudio.ps1
    调制解调器「猫叫」—— 呼叫进程音（Digital Call Progress / DCP）配置

    背景（实测结论）：
      1. LSI/Agere 软件猫的通话音由用户态服务 AgereModemAudio（agr64svc.exe）
         通过声卡回放，属于「数字声音」模式，需要在
             HKLM\SOFTWARE\Agere\SoftModem\AGRSMSetup  第三字节 0x04 = 1
         打开；音量在
             HKLM\SOFTWARE\Agere\SoftModem\DCPSpeakerVolume\SpeakerVolumeScale
      2. agr64svc.exe 启动时会打开 \\.\AGRSM 这条 DOS 设备名。而 agrsm64.sys
         只创建了 \Device\AGRSM_xface（即 \\.\AGRSM_xface），并不创建 \\.\AGRSM，
         所以服务打不开设备、ActiveModems 一直为 0，结果是：拨号时完全没有声音。
         解决办法：补一条 DOS 设备映射 AGRSM -> \Device\AGRSM_xface。
         - 立即生效：DefineDosDevice()（本脚本运行时做）
         - 重启后仍然生效：HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\DOS Devices
           下的 AGRSM 值（由 smss 在开机时加载，对所有会话有效）
      3. 原厂安装程序还会把 AGRSMMSG.exe 放到 %windir% 并加入 Run 项，本脚本照做。

    实测：补上映射 + 打开数字声音后，拨号时可从笔记本扬声器听到拨号音/回铃音。
#>

$script:AgereRoot     = 'HKLM:\SOFTWARE\Agere\SoftModem'
$script:DcpVolumeKey  = 'HKLM:\SOFTWARE\Agere\SoftModem\DCPSpeakerVolume'
$script:DosDevicesKey = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\DOS Devices'
$script:AgrsmAlias    = 'AGRSM'
$script:AgrsmTarget   = '\Device\AGRSM_xface'
$script:AudioSvcName  = 'AgereModemAudio'
$script:AppletName    = 'AGRSMMSG.exe'
$script:AgrsmSetupOk  = [byte[]](0x00, 0x08, 0xC6, 0x84)   # 第三字节 0x04 = 数字声音
$script:DcpVolumeVal  = [byte[]](0xFF)                      # 0xFF = 最大（原厂 0x32）

function _Say {
    param([string]$Message, [string]$Color = 'Gray')
    if (Get-Command Write-Log -ErrorAction SilentlyContinue) { Write-Log $Message $Color }
    else { Write-Host $Message -ForegroundColor $Color }
}

function Initialize-DosDeviceApi {
    if (-not ('DshModem.DosDev' -as [type])) {
        Add-Type -Namespace DshModem -Name DosDev -MemberDefinition @'
[System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError=true, CharSet=System.Runtime.InteropServices.CharSet.Ansi)]
public static extern bool DefineDosDeviceA(uint flags, string name, string target);
[System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError=true, CharSet=System.Runtime.InteropServices.CharSet.Ansi)]
public static extern System.IntPtr CreateFileA(string name, uint access, uint share, System.IntPtr sec, uint disp, uint flags, System.IntPtr tmpl);
[System.Runtime.InteropServices.DllImport("kernel32.dll")]
public static extern bool CloseHandle(System.IntPtr h);
'@
    }
}

function Test-AgrsmAliasOpenable {
    Initialize-DosDeviceApi
    foreach ($n in ('\\.\' + $script:AgrsmAlias), '\\.\AGRSM_xface') {
        $h = [DshModem.DosDev]::CreateFileA($n, [uint32]2147483648, 3, [IntPtr]::Zero, 3, 0, [IntPtr]::Zero)
        $ok = ($h.ToInt64() -ne -1)
        if ($ok) { [DshModem.DosDev]::CloseHandle($h) | Out-Null }
        if ($n -like '*xface') { $xfaceOk = $ok } else { $aliasOk = $ok }
    }
    return [pscustomobject]@{ Alias = $aliasOk; Xface = $xfaceOk }
}

function Enable-ModemCallAudio {
    # 打开「猫叫」：数字声音标志 + 音量 + \\.\AGRSM 设备别名 + 应用小程序 + 服务
    param([string]$PackageRoot = $PSScriptRoot)

    _Say '正在配置调制解调器通话音（猫叫）……' 'Cyan'

    # ---- 1. 数字声音标志与音量 ----
    if (-not (Test-Path -LiteralPath $script:AgereRoot)) { New-Item -Path $script:AgereRoot -Force | Out-Null }
    Set-ItemProperty -LiteralPath $script:AgereRoot -Name 'AGRSMSetup' -Value $script:AgrsmSetupOk -Type Binary
    _Say ('  AGRSMSetup = ' + (($script:AgrsmSetupOk | ForEach-Object { $_.ToString('X2') }) -join ' ') + '  （已打开数字声音位）') 'Green'

    if (-not (Test-Path -LiteralPath $script:DcpVolumeKey)) { New-Item -Path $script:DcpVolumeKey -Force | Out-Null }
    Set-ItemProperty -LiteralPath $script:DcpVolumeKey -Name 'SpeakerVolumeScale' -Value $script:DcpVolumeVal -Type Binary
    _Say ('  DCPSpeakerVolume\SpeakerVolumeScale = ' + $script:DcpVolumeVal[0].ToString('X2')) 'Green'

    # ---- 2. \\.\AGRSM 设备别名（立即生效 + 重启后仍生效）----
    $created = $false
    if (Test-Path -LiteralPath $script:DosDevicesKey) {
        $cur = (Get-ItemProperty -LiteralPath $script:DosDevicesKey -Name $script:AgrsmAlias -ErrorAction SilentlyContinue).$script:AgrsmAlias
        if ($cur -ne $script:AgrsmTarget) {
            New-ItemProperty -LiteralPath $script:DosDevicesKey -Name $script:AgrsmAlias -Value $script:AgrsmTarget -PropertyType String -Force | Out-Null
            $created = $true
        }
        _Say ('  持久设备别名: HKLM\...\DOS Devices\' + $script:AgrsmAlias + ' = ' + $script:AgrsmTarget + $(if ($created) { '  （已写入，重启后仍有效）' } else { '  （已存在）' })) 'Green'
    } else {
        _Say '  警告：找不到 DOS Devices 注册表键，只能做本次运行期的别名。' 'Yellow'
    }
    Initialize-DosDeviceApi
    $null = [DshModem.DosDev]::DefineDosDeviceA(0x1, $script:AgrsmAlias, $script:AgrsmTarget)
    $st = Test-AgrsmAliasOpenable
    if ($st.Alias) { _Say '  \\.\AGRSM 当前可打开（呼叫进程服务可用）' 'Green' }
    else { _Say '  警告：\\.\AGRSM 仍无法打开，猫叫可能无声。' 'Yellow' }

    # ---- 3. 原厂应用小程序（音量/提示，随原厂安装程序一起装）----
    $appletSrc = Join-Path (Join-Path $PackageRoot 'support') $script:AppletName
    $appletDst = Join-Path $env:SystemRoot $script:AppletName
    if (Test-Path -LiteralPath $appletSrc) {
        if (-not (Test-Path -LiteralPath $appletDst)) {
            Copy-Item -LiteralPath $appletSrc -Destination $appletDst -Force
            _Say ('  已安装 ' + $appletDst) 'Green'
        } else {
            _Say ('  ' + $appletDst + ' 已存在') 'Gray'
        }
        $runKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
        $cur = (Get-ItemProperty -LiteralPath $runKey -Name 'AGRSMMSG' -ErrorAction SilentlyContinue).AGRSMMSG
        if ($cur -ne $script:AppletName) {
            New-ItemProperty -LiteralPath $runKey -Name 'AGRSMMSG' -Value $script:AppletName -PropertyType String -Force | Out-Null
            _Say '  已加入开机启动: Run\AGRSMMSG = AGRSMMSG.exe' 'Green'
        }
        if (-not (Get-Process -Name 'AGRSMMSG' -ErrorAction SilentlyContinue)) {
            try { Start-Process -FilePath $appletDst -ErrorAction Stop; _Say '  已启动 AGRSMMSG.exe' 'Green' } catch { _Say ('  启动 AGRSMMSG.exe 失败：' + $_.Exception.Message) 'Yellow' }
        }
    } else {
        _Say '  提示：包内没有 support\AGRSMMSG.exe，跳过原厂小程序（不影响通话音）。' 'Yellow'
    }

    # ---- 4. 呼叫进程音服务 ----
    $svc = Get-Service -Name $script:AudioSvcName -ErrorAction SilentlyContinue
    if (-not $svc) {
        $bin = Join-Path $env:ProgramFiles 'LSI SoftModem\agr64svc.exe'
        if (Test-Path -LiteralPath $bin) {
            & sc.exe create $script:AudioSvcName type= own start= auto binPath= ('"' + $bin + '"') DisplayName= 'Agere Modem Call Progress Audio' 2>&1 | Out-Null
            _Say ('  已创建服务 ' + $script:AudioSvcName) 'Green'
            $svc = Get-Service -Name $script:AudioSvcName -ErrorAction SilentlyContinue
        } else {
            _Say ('  警告：找不到 ' + $bin + '，无法提供通话音服务。') 'Yellow'
        }
    }
    if ($svc) {
        if ($svc.Status -ne 'Running') {
            try { Start-Service -Name $script:AudioSvcName -ErrorAction Stop } catch { try { Restart-Service -Name $script:AudioSvcName -Force -ErrorAction Stop } catch {} }
        }
        $svc = Get-Service -Name $script:AudioSvcName -ErrorAction SilentlyContinue
        _Say ('  服务 ' + $script:AudioSvcName + '：' + $svc.Status) $(if ($svc.Status -eq 'Running') { 'Green' } else { 'Yellow' })
    }
}

function Get-ModemCallAudioState {
    # 返回「猫叫」相关配置的检查结果，供 Verify.ps1 使用
    $checks = New-Object System.Collections.ArrayList

    $setup = (Get-ItemProperty -LiteralPath $script:AgereRoot -Name 'AGRSMSetup' -ErrorAction SilentlyContinue).AGRSMSetup
    $hasDigital = $false
    if ($setup -is [byte[]] -and $setup.Length -ge 4) { $hasDigital = (($setup[3] -band 0x04) -ne 0) }
    $null = $checks.Add([pscustomobject]@{ Name = 'AGRSMSetup 数字声音位(0x04)'; Pass = $hasDigital; Detail = $(if ($setup) { (($setup | ForEach-Object { $_.ToString('X2') }) -join ' ') } else { '<未设置>' }) })

    $vol = (Get-ItemProperty -LiteralPath $script:DcpVolumeKey -Name 'SpeakerVolumeScale' -ErrorAction SilentlyContinue).SpeakerVolumeScale
    $null = $checks.Add([pscustomobject]@{ Name = 'DCPSpeakerVolume 已设置'; Pass = [bool]$vol; Detail = $(if ($vol) { ('0x' + (($vol | ForEach-Object { $_.ToString('X2') }) -join '')) } else { '<未设置>' }) })

    $aliasReg = $null
    if (Test-Path -LiteralPath $script:DosDevicesKey) {
        $aliasReg = (Get-ItemProperty -LiteralPath $script:DosDevicesKey -Name $script:AgrsmAlias -ErrorAction SilentlyContinue).$script:AgrsmAlias
    }
    $null = $checks.Add([pscustomobject]@{ Name = 'DOS 设备别名 AGRSM (重启后仍有效)'; Pass = ($aliasReg -eq $script:AgrsmTarget); Detail = [string]$aliasReg })

    $st = Test-AgrsmAliasOpenable
    $null = $checks.Add([pscustomobject]@{ Name = '\\.\AGRSM 可打开 (呼叫进程服务前提)'; Pass = $st.Alias; Detail = $(if ($st.Alias) { 'OK' } else { '打不开' }) })

    $svc = Get-Service -Name $script:AudioSvcName -ErrorAction SilentlyContinue
    $null = $checks.Add([pscustomobject]@{ Name = '服务 AgereModemAudio 运行中'; Pass = ($svc -and $svc.Status -eq 'Running'); Detail = $(if ($svc) { $svc.Status.ToString() } else { '<不存在>' }) })

    $applet = Join-Path $env:SystemRoot $script:AppletName
    $null = $checks.Add([pscustomobject]@{ Name = '原厂小程序 AGRSMMSG.exe 已安装'; Pass = (Test-Path -LiteralPath $applet); Detail = $applet })

    return $checks
}
