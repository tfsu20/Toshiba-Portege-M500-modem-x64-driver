@echo off
setlocal EnableExtensions EnableDelayedExpansion
title TOSHIBA M500 Modem Driver Setup
echo ==============================================================
echo  TOSHIBA PORTEGE M500 - Modem Driver + Voice Dialer Setup
echo  Windows 7 x64 / 8 / 8.1 / 10 / 11 x64
echo ==============================================================
echo.
net session >nul 2>&1
if not "!errorlevel!"=="0" (
  echo Requesting administrator privileges...
  mshta "javascript:new ActiveXObject('Shell.Application').ShellExecute('%~f0','','%~dp0','runas',1);close()" >nul 2>&1
  exit /b
)
set "PKG=%~dp0"
if "%PKG:~-1%"=="\" set "PKG=%PKG:~0,-1%"
set "DEST=%ProgramFiles%\TOSHIBA M500 Modem"
echo [1/7] Copying files to "%DEST%" ...
if not exist "%DEST%" md "%DEST%" >nul 2>&1
if not exist "%DEST%\driver" md "%DEST%\driver" >nul 2>&1
xcopy "%PKG%\driver\*" "%DEST%\driver\" /E /I /Y /Q >nul 2>&1
if exist "%PKG%\tools" ( md "%DEST%\tools" >nul 2>&1 & xcopy "%PKG%\tools\*" "%DEST%\tools\" /E /I /Y /Q >nul 2>&1 )
if exist "%PKG%\support" ( md "%DEST%\support" >nul 2>&1 & xcopy "%PKG%\support\*" "%DEST%\support\" /E /I /Y /Q >nul 2>&1 )
if exist "%PKG%\README.txt" copy /y "%PKG%\README.txt" "%DEST%\README.txt" >nul 2>&1
echo       done.
echo [2/7] Importing driver package ...
set "INF=%DEST%\driver\lsimdv64.inf"
set "PNPUTIL=%SystemRoot%\System32\pnputil.exe"
"%PNPUTIL%" /add-driver "%INF%" /install >"%TEMP%\m500_add.log" 2>&1
if not "!errorlevel!"=="0" "%PNPUTIL%" -a "%INF%" -i >>"%TEMP%\m500_add.log" 2>&1
findstr /i /c:"successfully" /c:"up-to-date" /c:"added" "%TEMP%\m500_add.log" >nul 2>&1
if errorlevel 1 ( echo       [!] import reported problems - see "%TEMP%\m500_add.log" ) else ( echo       driver package imported. )
echo [3/7] Installing load-name binary ...
copy /y "%DEST%\driver\tosm500md.sys" "%SystemRoot%\System32\drivers\tosm500md.sys" >nul 2>&1
if exist "%SystemRoot%\System32\drivers\tosm500md.sys" ( echo       done. ) else ( echo       [!] copy failed - reboot and rerun. )
echo [4/7] Redirecting service ImagePath ...
reg add "HKLM\SYSTEM\CurrentControlSet\Services\AgereSoftModem" /v ImagePath /t REG_EXPAND_SZ /d "\SystemRoot\system32\DRIVERS\tosm500md.sys" /f >nul 2>&1
reg query "HKLM\SYSTEM\CurrentControlSet\Services\AgereSoftModem" /v ImagePath 2>nul | findstr /i tosm500md >nul
if errorlevel 1 ( echo       [!] service not found yet. ) else ( echo       done. )
echo [5/7] Writing Agere audio configuration ...
reg add "HKLM\SOFTWARE\Agere\SoftModem" /v AGRSMSetup /t REG_BINARY /d 0008c684 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Agere\SoftModem" /v MessageAppletDisable /t REG_BINARY /d 00 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Agere\SoftModem\DCPSpeakerVolume" /v SpeakerVolumeScale /t REG_BINARY /d 32 /f >nul 2>&1
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\DOS Devices" /v AGRSM /t REG_SZ /d "\Device\AGRSM_xface" /f >nul 2>&1
echo       done.
echo [6/7] Restarting the modem device ...
set "DEVPARENT="
for /f "tokens=1" %%a in ('reg query "HKLM\SYSTEM\CurrentControlSet\Enum\HDAUDIO" 2^>nul ^| findstr /i "FUNC_02&VEN_11C1&DEV_3026"') do if not defined DEVPARENT set "DEVPARENT=%%a"
set "INSTFULL="
if defined DEVPARENT (
  for /f "tokens=1" %%a in ('reg query "!DEVPARENT!" 2^>nul ^| findstr /b /i "HKEY"') do if not defined INSTFULL set "INSTFULL=%%a"
)
if defined INSTFULL (
  set "INSTID=!INSTFULL:*\Enum\=!"
  "%PNPUTIL%" /restart-device "!INSTID!" >nul 2>&1
  if errorlevel 1 ( echo       restart unsupported - disable/enable the modem manually. ) else ( echo       done. )
) else ( echo       [!] modem device not found in registry. )
echo [7/7] Creating desktop shortcuts ...
set "DESK=%PUBLIC%\Desktop"
if not exist "%DESK%" set "DESK=%SystemDrive%\Users\Public\Desktop"
if exist "%PKG%\Shortcut\*.lnk" (
  copy /y "%PKG%\Shortcut\*.lnk" "%DESK%\" >nul 2>&1
  echo       shortcuts copied to desktop.
) else ( echo       [!] no shortcuts in package. )
echo.
echo ==============================================================
echo  Finished.
echo   Dialer   : "%DEST%\tools\ModemVoicePhone.exe"
echo   Readme   : "%DEST%\README.txt"
echo   Desktop  : two shortcuts created
echo ==============================================================
echo.
pause
exit /b 0