using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

// ModemVoicePhone - dial + hear + talk over an Agere/LSI HDA soft modem (voice class 8)
// Usage: ModemVoicePhone.exe <COMx> <number>
public static class ModemVoicePhone
{
    [DllImport("kernel32.dll")] static extern IntPtr GetConsoleWindow();
    [DllImport("kernel32.dll")] static extern bool AllocConsole();
    [DllImport("kernel32.dll")] static extern bool FreeConsole();

    static void EnsureConsole()
    {
        if (GetConsoleWindow() == IntPtr.Zero)
        {
            if (AllocConsole())
            {
                try { Console.SetIn(new System.IO.StreamReader(Console.OpenStandardInput(), Console.InputEncoding)); } catch { }
                try { Console.SetOut(new System.IO.StreamWriter(Console.OpenStandardOutput(), Console.OutputEncoding) { AutoFlush = true }); } catch { }
            }
        }
    }

    static string Ask(string prompt)
    {
        for (int tries = 0; tries < 600; tries++)
        {
            Console.Write(prompt);
            string s = null;
            try { s = Console.ReadLine(); } catch { }
            if (s != null) return s.Trim();
            Thread.Sleep(100);
        }
        return "";
    }
    // ---------- WinMM ----------
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    struct WAVEFORMATEX { public ushort wFormatTag, nChannels; public uint nSamplesPerSec, nAvgBytesPerSec; public ushort nBlockAlign, wBitsPerSample, cbSize; }
    [StructLayout(LayoutKind.Sequential)]
    struct WAVEHDR { public IntPtr lpData; public uint dwBufferLength, dwBytesRecorded, dwUser, dwFlags, dwLoops; public IntPtr lpNext, reserved; }

    [DllImport("winmm.dll")] static extern int waveOutOpen(out IntPtr h, uint dev, ref WAVEFORMATEX wf, IntPtr cb, IntPtr inst, uint flags);
    [DllImport("winmm.dll")] static extern int waveOutPrepareHeader(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveOutWrite(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveOutReset(IntPtr h);
    [DllImport("winmm.dll")] static extern int waveOutClose(IntPtr h);
    [DllImport("winmm.dll")] static extern int waveOutUnprepareHeader(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveInOpen(out IntPtr h, uint dev, ref WAVEFORMATEX wf, IntPtr cb, IntPtr inst, uint flags);
    [DllImport("winmm.dll")] static extern int waveInPrepareHeader(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveInUnprepareHeader(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveInAddBuffer(IntPtr h, IntPtr hdr, int size);
    [DllImport("winmm.dll")] static extern int waveInStart(IntPtr h);
    [DllImport("winmm.dll")] static extern int waveInStop(IntPtr h);
    [DllImport("winmm.dll")] static extern int waveInReset(IntPtr h);
    [DllImport("winmm.dll")] static extern int waveInClose(IntPtr h);

    static IntPtr hOut = IntPtr.Zero;
    static WAVEFORMATEX fmt;
    static SerialPort sp;
    static volatile bool running = true;
    static volatile bool talking = false;
    static long rxBytes = 0;

    // mu-law <-> pcm16
    static short MuToPcm(byte u)
    {
        u = (byte)~u;
        int sign = u & 0x80, exp = (u >> 4) & 7, mant = u & 0x0F;
        int mag = (((mant << 3) + 0x84) << exp) - 0x84;
        return (short)(sign != 0 ? -mag : mag);
    }
    static bool unescape = true;        // /e:1 enable <DLE> unescaping (off by default)
    static int sampleRate = 10000;      // measured: 9,982 B/s after DLE unescaping        // playback Hz (/r:N) -- tune to match the modem stream
    static int voiceFormat = 5;          // 5 = G.711A (China), 4 = G.711U
    static readonly int[] segA = { 0x1F,0x3F,0x7F,0xFF,0x1FF,0x3FF,0x7FF,0xFFF };

    static short ALawToPcm(byte a)
    {
        a ^= 0x55;
        int v = (a & 0x0F) << 4;
        int seg = (a & 0x70) >> 4;
        if (seg == 0) v += 8;
        else if (seg == 1) v += 0x108;
        else { v += 0x108; v <<= (seg - 1); }
        return (short)(((a & 0x80) != 0) ? v : -v);
    }

    static byte PcmToALaw(short s)
    {
        int p = s >> 3;
        int mask;
        if (p >= 0) mask = 0xD5; else { mask = 0x55; p = -p - 1; }
        int seg = 0;
        while (seg < 8 && p > segA[seg]) seg++;
        if (seg >= 8) return (byte)(0x7F ^ mask);
        int aval = seg << 4;
        aval |= (seg < 2) ? ((p >> 1) & 0x0F) : ((p >> seg) & 0x0F);
        return (byte)(aval ^ mask);
    }

    static byte PcmToMu(short s)
    {
        const int BIAS = 0x84, CLIP = 32635;
        int sign = (s < 0) ? 0x80 : 0;
        int v = s; if (v < 0) v = -v; if (v > CLIP) v = CLIP; v += BIAS;
        int exp = 7; for (int m = 0x4000; (v & m) == 0 && exp > 0; m >>= 1) exp--;
        int mant = (v >> (exp + 3)) & 0x0F;
        return (byte)~(sign | (exp << 4) | mant);
    }

    static string Cmd(string c, int ms)
    {
        try { sp.DiscardInBuffer(); } catch { }
        sp.Write(c + "\r");
        var sb = new StringBuilder();
        DateTime end = DateTime.Now.AddMilliseconds(ms);
        while (DateTime.Now < end)
        {
            if (sp.BytesToRead > 0)
            {
                int v = sp.ReadByte(); if (v < 0) continue;
                char ch = (char)v;
                if (ch == '\r') { string l = sb.ToString().Trim(); sb.Length = 0; if (l.Length > 0 && !l.StartsWith("AT")) return Sanitize(l); }
                else if (ch != '\n') sb.Append(ch);
            }
            else Thread.Sleep(2);
        }
        return Sanitize(sb.ToString().Trim());
    }

    static string Sanitize(string s)
    {
        var sb = new StringBuilder();
        foreach (char c in s) if (c >= 32 && c < 127) sb.Append(c);
        string r = sb.ToString().Trim();
        if (r.Length > 120) r = r.Substring(0, 120);
        return r;
    }

    // ---------- playback: pre-allocated buffer pool (zero allocation per chunk) ----------
    const int NSLOT = 16;
    const int SLOT_SAMPLES = 400;            // input samples per chunk (~40 ms @10 kHz)
    const int SLOT_OUT = 2048;               // max upsampled samples per slot (48 kHz)
    static IntPtr[] slotBuf = new IntPtr[NSLOT];
    static IntPtr[] slotHdr = new IntPtr[NSLOT];
    static bool[] slotUsed = new bool[NSLOT];
    static float dcX = 0f, dcY = 0f;
    static float outGain = 1.0f;
    static float gateLevel = 260f;
    static short[] pcmIn = null, pcmOut = null;
    static short rsPrev = 0;
    static double rsPos = 1.0;
    static int warmupSkip = 2;
    static int throttled = 0;
    static bool prebuffered = false;
    static long lastSend = 0;               // resampler phase (continues across chunks)

    static void InitSlots()
    {
        if (hOut == IntPtr.Zero) return;
        int sz = Marshal.SizeOf(typeof(WAVEHDR));
        for (int i = 0; i < NSLOT; i++)
        {
            slotBuf[i] = Marshal.AllocHGlobal(SLOT_OUT * 2);
            slotHdr[i] = Marshal.AllocHGlobal(sz);
            WAVEHDR w = new WAVEHDR();
            w.lpData = slotBuf[i];
            w.dwBufferLength = (uint)(SLOT_OUT * 2);
            Marshal.StructureToPtr(w, slotHdr[i], false);
            waveOutPrepareHeader(hOut, slotHdr[i], sz);
            slotUsed[i] = false;
        }
    }

    static int FindFreeSlot()
    {
        for (int i = 0; i < NSLOT; i++)
        {
            if (!slotUsed[i]) return i;
            WAVEHDR w = (WAVEHDR)Marshal.PtrToStructure(slotHdr[i], typeof(WAVEHDR));
            if ((w.dwFlags & 0x00000001) != 0) return i;
        }
        return -1;
    }

    static void Play(byte[] ulaw, int count)
    {
        if (hOut == IntPtr.Zero || count < 2) return;
        if (count > SLOT_SAMPLES) count = SLOT_SAMPLES;
        int idx = FindFreeSlot();
        if (idx < 0)
        {
            DateTime lim = DateTime.Now.AddMilliseconds(80);
            while (idx < 0 && DateTime.Now < lim) { Thread.Sleep(2); idx = FindFreeSlot(); }
            if (idx < 0) { drops++; return; }
        }
        if (pcmIn == null || pcmIn.Length < count + 2) pcmIn = new short[count + 2];
        if (pcmOut == null) pcmOut = new short[SLOT_OUT];
        pcmIn[0] = rsPrev;
        for (int i = 0; i < count; i++)
        {
            float x = (voiceFormat == 5) ? ALawToPcm(ulaw[i]) : MuToPcm(ulaw[i]);
            dcY = x - dcX + 0.995f * dcY; dcX = x;
            if (Math.Abs(dcY) < gateLevel) dcY *= 0.12f;
            float g = dcY * outGain;
            if (g > 32767f) g = 32767f;
            if (g < -32768f) g = -32768f;
            pcmIn[i + 1] = (short)g;
        }
        pcmIn[count + 1] = pcmIn[count];
        rsPrev = pcmIn[count];
        // linear interpolation: sourceRate -> 48000
        double step = 1.0;   // direct playback (no resampling)
        int o = 0; double pos = rsPos;
        while (pos < count && o < SLOT_OUT - 1)
        {
            int i = (int)pos; double fr = pos - i;
            double v = pcmIn[i] + (pcmIn[i + 1] - pcmIn[i]) * fr;
            pcmOut[o++] = (short)v;
            pos += step;
        }
        rsPos = pos - count;
        if (rsPos < 0 || rsPos > 4) rsPos = 1.0;
        if (o < 2) return;
        Marshal.Copy(pcmOut, 0, slotBuf[idx], o);
        WAVEHDR h = (WAVEHDR)Marshal.PtrToStructure(slotHdr[idx], typeof(WAVEHDR));
        h.dwBufferLength = (uint)(o * 2);
        h.dwFlags = 0x00000002;
        Marshal.StructureToPtr(h, slotHdr[idx], false);
        slotUsed[idx] = true;
        waveOutWrite(hOut, slotHdr[idx], Marshal.SizeOf(typeof(WAVEHDR)));
    }
    static void Reap() { }

    static void OpenAudio()
    {
        fmt = new WAVEFORMATEX();
        fmt.wFormatTag = 1; fmt.nChannels = 1; fmt.nSamplesPerSec = (uint)sampleRate;
        fmt.wBitsPerSample = 16; fmt.nBlockAlign = 2; fmt.nAvgBytesPerSec = (uint)(sampleRate * 2); fmt.cbSize = 0;
        int hr = waveOutOpen(out hOut, 0xFFFFFFFF, ref fmt, IntPtr.Zero, IntPtr.Zero, 0);
        if (hr != 0) { Console.WriteLine("[warn] waveOutOpen failed: " + hr); hOut = IntPtr.Zero; }
        InitSlots();
    }

    // ---------- microphone (waveIn, 8k/16/mono, polled) ----------
    static IntPtr hIn = IntPtr.Zero;
    static IntPtr[] inHdr, inBuf;
    const int INBUF = 1600;                     // 100 ms

    static void OpenMic()
    {
        int hr = waveInOpen(out hIn, 0xFFFFFFFF, ref fmt, IntPtr.Zero, IntPtr.Zero, 0);
        if (hr != 0) { Console.WriteLine("[warn] waveInOpen failed: " + hr + " (no microphone?)"); hIn = IntPtr.Zero; return; }
        inHdr = new IntPtr[3]; inBuf = new IntPtr[3];
        int sz = Marshal.SizeOf(typeof(WAVEHDR));
        for (int i = 0; i < 3; i++)
        {
            inBuf[i] = Marshal.AllocHGlobal(INBUF);
            inHdr[i] = Marshal.AllocHGlobal(sz);
            WAVEHDR w = new WAVEHDR();
            w.lpData = inBuf[i]; w.dwBufferLength = (uint)INBUF;
            Marshal.StructureToPtr(w, inHdr[i], false);
            waveInPrepareHeader(hIn, inHdr[i], sz);
            waveInAddBuffer(hIn, inHdr[i], sz);
        }
        waveInStart(hIn);
    }

    static int MicRead(byte[] dest)
    {
        if (hIn == IntPtr.Zero) return 0;
        int sz = Marshal.SizeOf(typeof(WAVEHDR));
        for (int i = 0; i < inHdr.Length; i++)
        {
            WAVEHDR w = (WAVEHDR)Marshal.PtrToStructure(inHdr[i], typeof(WAVEHDR));
            if ((w.dwFlags & 0x00000001) != 0)
            {
                int n = (int)w.dwBytesRecorded;
                if (n > dest.Length) n = dest.Length;
                if (n > 0) Marshal.Copy(inBuf[i], dest, 0, n);
                waveInUnprepareHeader(hIn, inHdr[i], sz);
                waveInPrepareHeader(hIn, inHdr[i], sz);
                waveInAddBuffer(hIn, inHdr[i], sz);
                return n;
            }
        }
        return 0;
    }

    // ---------- voice mode switching ----------
    static void DrainPort() { try { while (sp.BytesToRead > 0) sp.ReadByte(); } catch { } }
    static void SendDle() { try { byte[] d = new byte[] { 0x10, 0x03 }; sp.Write(d, 0, 2); } catch { } }

    // IMPORTANT: AT+VLS=1 connects voice to the line. Sending it a SECOND time while
    // the call is up tears the connection down (this is exactly why choosing an option
    // in the XP dialer dropped the call). So it is sent only once, before the first
    // AT+VRX, and again only after a AT+VTX burst.
    static void EnterRx(bool rearmAnalog)
    {
        DrainPort();
        if (rearmAnalog)
        {
            sp.Write("AT+VLS=1\r");
            Thread.Sleep(150);
            DrainPort();
        }
        sp.Write("AT+VRX\r");
        // consume ONLY the textual response line, never the voice payload
        DateTime end = DateTime.Now.AddMilliseconds(600);
        while (DateTime.Now < end)
        {
            if (sp.BytesToRead > 0)
            {
                int v = sp.ReadByte(); if (v < 0) continue;
                if (v == 0x0A) break;                      // end of "OK\r\n" / "VCON\r\n"
                if (v < 9 || (v > 13 && v < 32) || v > 126) break;   // binary => stream already started
            }
            else Thread.Sleep(2);
        }
        rxEscape = false; rxPend.Clear();
        rxStreaming = true;
    }

    static void EnterTx()
    {
        rxStreaming = false;
        SendDle();                   // end current +VRX stream
        Thread.Sleep(250);
        DrainPort();
        sp.Write("AT+VTX\r");
        Thread.Sleep(300);
        DrainPort();                 // drop the modem's <DLE><XON>/OK prompt
    }

    static void LeaveTx()
    {
        rxStreaming = false;
        SendDle();                   // end +VTX stream
        Thread.Sleep(250);
        DrainPort();
    }

    static List<byte> rxPend = new List<byte>(4096);
    static readonly Queue<byte[]> playQ = new Queue<byte[]>();
    static readonly object playLock = new object();
    static readonly AutoResetEvent playEvt = new AutoResetEvent(false);
    static Thread playThread;
    static volatile bool playRun = true;
    static int drops = 0;

    static void StartPlayer()
    {
        playRun = true;
        playThread = new Thread(delegate ()
        {
            while (playRun)
            {
                playEvt.WaitOne(10);
                while (true)
                {
                    byte[] c = null;
                    lock (playLock)
                    {
                        if (playQ.Count == 0) break;
                        c = playQ.Dequeue();
                    }
                    Play(c, c.Length);
                }
            }
        });
        playThread.IsBackground = true;
        playThread.Priority = ThreadPriority.Highest;
        playThread.Start();
    }

    static void Enqueue(byte[] chunk)
    {
        lock (playLock)
        {
            if (playQ.Count >= 24) { playQ.Dequeue(); drops++; }   // bound latency at ~200 ms
            playQ.Enqueue(chunk);
        }
        playEvt.Set();
    }
    static bool rxEscape = false;

    static void PumpRx()
    {
        int avail;
        try { avail = sp.BytesToRead; } catch { return; }
        if (avail <= 0) return;
        byte[] tmp = new byte[Math.Min(avail, 4096)];
        int got = sp.Read(tmp, 0, tmp.Length);
        for (int i = 0; i < got; i++)
        {
            byte b = tmp[i];
            if (!unescape) { rxPend.Add(b); continue; }        // raw stream: no DLE handling at all
            if (rxEscape) { rxEscape = false; if (b == 0x03) continue; rxPend.Add(b); }
            else if (b == 0x10) rxEscape = true;
            else rxPend.Add(b);
        }
        Reap();
        while (rxPend.Count >= 400)
        {
            byte[] c = rxPend.GetRange(0, 400).ToArray();
            rxPend.RemoveRange(0, 400);
            if (warmupSkip > 0) { warmupSkip--; }
            else Enqueue(c);
        }
    }

    // ---------- dedicated blocking reader (never leaves a polling gap) ----------
    static volatile bool rxStreaming = false;
    static long rxTotal = 0;
    static DateTime rxT0 = DateTime.MinValue;

    static void ReaderLoop()
    {
        byte[] buf = new byte[8192];
        while (playRun)
        {
            if (!rxStreaming) { Thread.Sleep(3); continue; }
            int n;
            try { n = sp.Read(buf, 0, buf.Length); }
            catch (TimeoutException) { continue; }
            catch { break; }
            if (n <= 0) continue;
            rxTotal += n;
            if (rxT0 == DateTime.MinValue) rxT0 = DateTime.Now;
            for (int i = 0; i < n; i++)
            {
                byte b = buf[i];
                if (!unescape) { rxPend.Add(b); continue; }
                if (rxEscape) { rxEscape = false; if (b == 0x03) continue; rxPend.Add(b); }
                else if (b == 0x10) rxEscape = true;
                else rxPend.Add(b);
            }
            while (rxPend.Count >= 400)
            {
                byte[] c = rxPend.GetRange(0, 400).ToArray();
                rxPend.RemoveRange(0, 400);
                if (warmupSkip > 0) { warmupSkip--; }
                else Enqueue(c);
            }
        }
    }
    static void PumpTx(byte[] mic, byte[] outbuf)
    {
        int n = MicRead(mic);
        if (n <= 0) return;
        int samples = n / 2, o = 0;
        for (int i = 0; i < samples; i++)
        {
            short pcmS = BitConverter.ToInt16(mic, i * 2);
            byte mu = (voiceFormat == 5) ? PcmToALaw(pcmS) : PcmToMu(pcmS);
            if (mu == 0x10) { outbuf[o++] = 0x10; outbuf[o++] = 0x10; }   // escape DLE
            else outbuf[o++] = mu;
            if (o >= outbuf.Length - 2) break;
        }
        if (o > 0) sp.Write(outbuf, 0, o);
    }

    static void HardReset()
    {
        SendDle(); Thread.Sleep(300); DrainPort();
        Thread.Sleep(1100);
        try { sp.Write("+++"); } catch { }
        Thread.Sleep(1100); DrainPort();
        try { sp.Write("ATH\r"); } catch { } Thread.Sleep(400); DrainPort();
        try { sp.Write("AT+FCLASS=0\r"); } catch { } Thread.Sleep(300); DrainPort();
        try { sp.Write("ATZ\r"); } catch { } Thread.Sleep(1200); DrainPort();
    }

    static bool SetVoiceMode()
    {
        for (int i = 1; i <= 4; i++)
        {
            string r = Cmd("AT+FCLASS=8", 2500);
            Console.WriteLine("AT+FCLASS=8  -> " + r + (i > 1 ? "   (第 " + i + " 次)" : ""));
            if (r == "OK") return true;
            HardReset();
        }
        return false;
    }
    public static int Main(string[] args)
    {
        string port = args.Length > 0 ? args[0] : "COM3";
        string number = args.Length > 1 ? args[1] : null;
        EnsureConsole();
        if (string.IsNullOrEmpty(number))
        {
            Console.WriteLine();
            Console.WriteLine("=== 调制解调器拨号控制台（可直接输入号码）===");
            string pin = Ask("COM 口 [" + port + "]: ");
            if (pin.Length > 0) port = pin;
            while (true)
            {
                number = Ask("要拨打的号码: ");
                if (number.Length > 0) break;
                Console.WriteLine("号码不能为空，请重新输入。");
            }
        }
        foreach (string s in args)
        {
            if (s.StartsWith("/q:")) { float q; if (float.TryParse(s.Substring(3), out q)) gateLevel = q; }
            if (s.StartsWith("/e:")) { unescape = (s.Substring(3).Trim() == "1"); }
            if (s.StartsWith("/w:")) { int wv; if (int.TryParse(s.Substring(3), out wv)) warmupSkip = wv; }
            if (s.StartsWith("/r:")) { int rr; if (int.TryParse(s.Substring(3), out rr) && rr >= 4000 && rr <= 24000) sampleRate = rr; }
            if (s.StartsWith("/f:")) { int fv; if (int.TryParse(s.Substring(3), out fv)) voiceFormat = fv; }
            if (s.StartsWith("/v:")) { float v; if (float.TryParse(s.Substring(3), out v)) outGain = v / 100f; }
        }
        int limitSec = 0;
        if (args.Length > 2) int.TryParse(args[2], out limitSec);
        bool autoTest = args.Length > 3 && args[3] == "test";

        Console.WriteLine("=== Modem Voice Phone (2-way) ===  port=" + port + "  number=" + number + "  rate=" + sampleRate);
        sp = new SerialPort(port, 115200, Parity.None, 8, StopBits.One);
        sp.ReadTimeout = 500; sp.WriteTimeout = 1500; sp.DtrEnable = true; sp.RtsEnable = true;
        sp.Handshake = Handshake.None;
        sp.ReadBufferSize = 1 << 16;
        try { sp.Open(); } catch (Exception ex) { Console.WriteLine("open failed: " + ex.Message); return 2; }

        fmt = new WAVEFORMATEX();
        fmt.wFormatTag = 1; fmt.nChannels = 1; fmt.nSamplesPerSec = (uint)sampleRate;
        fmt.wBitsPerSample = 16; fmt.nBlockAlign = 2; fmt.nAvgBytesPerSec = (uint)(sampleRate * 2); fmt.cbSize = 0;
        int hr = waveOutOpen(out hOut, 0xFFFFFFFF, ref fmt, IntPtr.Zero, IntPtr.Zero, 0);
        if (hr != 0) { Console.WriteLine("[warn] waveOutOpen failed: " + hr); hOut = IntPtr.Zero; }
        InitSlots();

        Console.CancelKeyPress += delegate { try { HardReset(); } catch { } };

        Console.WriteLine("-- 清理残留状态（DLE/ETX、+++、ATH、FCLASS=0、ATZ）--");
        HardReset();
        if (!SetVoiceMode())
        {
            Console.WriteLine();
            Console.WriteLine("无法进入语音模式。请运行 Install.cmd（或重启设备）后再试。");
            Console.WriteLine("按回车退出..."); Console.ReadLine();
            return 3;
        }
        Console.WriteLine("AT+VSM=" + voiceFormat + "     -> " + Cmd("AT+VSM=" + voiceFormat, 2000));
        Console.WriteLine("AT+VLS=0     -> " + Cmd("AT+VLS=0", 2000));
        Console.WriteLine("ATD" + number + "     -> " + Cmd("ATD" + number, 20000));
        Console.WriteLine("AT+VLS=1     -> " + Cmd("AT+VLS=1", 2500));   // 只发这一次

        StartPlayer();
        EnterRx(false);
        OpenMic();
        bool txMode = false;
        byte[] mic = new byte[INBUF + 8];
        byte[] obuf = new byte[INBUF * 2 + 8];
        long rxBytes = 0, txBytes = 0;

        Console.WriteLine();
        Console.WriteLine("你现在能听到线路声音（回铃音/对方说话）。");
        Console.WriteLine("按 SPACE 切换「说话/聆听」，ESC 或 Q 挂机。");
        Console.WriteLine("  [1] 说话中... (另一次 SPACE 回到聆听)");
        Console.WriteLine("  [0] 聆听中... (SPACE 开始说话)");
        Console.WriteLine();

        DateTime t0 = DateTime.Now;
        DateTime lastFlip = DateTime.Now;
        while (true)
        {
            if (limitSec > 0 && (DateTime.Now - t0).TotalSeconds >= limitSec) break;

            if (!txMode) PumpRx(); else PumpTx(mic, obuf);

            bool flip = false;
            try
            {
                while (Console.KeyAvailable)
                {
                    ConsoleKeyInfo k = Console.ReadKey(true);
                    if (k.Key == ConsoleKey.Escape || k.Key == ConsoleKey.Q) { flip = false; goto done; }
                    if (k.Key == ConsoleKey.Spacebar) flip = true;
                }
            }
            catch { }

            // automated self-test: RX 3s -> TX 4s -> RX 2s
            if (autoTest && (DateTime.Now - lastFlip).TotalSeconds > (txMode ? 4 : 3))
            {
                flip = true; lastFlip = DateTime.Now;
                if (txMode && (DateTime.Now - t0).TotalSeconds > 8) break;
            }

            if (flip)
            {
                if (!txMode) { EnterTx(); txMode = true; Console.WriteLine("[1] 说话中（麦克风→线路）..."); }
                else { LeaveTx(); EnterRx(true); txMode = false; Console.WriteLine("[0] 聆听中（线路→扬声器）..."); }
            }
            if (sp.BytesToRead == 0) Thread.Sleep(2);
        }
    done:
        if (txMode) { LeaveTx(); }
        Console.WriteLine("\nHanging up ...");
        try { HardReset(); } catch { }
        SendDle(); Thread.Sleep(400); DrainPort();
        Console.WriteLine("AT+FCLASS=0  -> " + Cmd("AT+FCLASS=0", 2000));
        Console.WriteLine("ATH          -> " + Cmd("ATH", 2000));
        Console.WriteLine("ATZ          -> " + Cmd("ATZ", 2000));
        double secs = rxT0 == DateTime.MinValue ? 0 : (DateTime.Now - rxT0).TotalSeconds;
        Console.WriteLine("(rx=" + rxTotal + " B in " + secs.ToString("F1") + " s -> " + (secs > 0 ? (rxTotal / secs).ToString("F0") : "0") + " B/s,  playback drops=" + drops + ")");
        try { sp.Close(); } catch { }
        if (hIn != IntPtr.Zero) { waveInStop(hIn); waveInReset(hIn); waveInClose(hIn); }
        if (hOut != IntPtr.Zero) { waveOutReset(hOut); waveOutClose(hOut); }
        Console.WriteLine("Done.");
        return 0;
    }
}