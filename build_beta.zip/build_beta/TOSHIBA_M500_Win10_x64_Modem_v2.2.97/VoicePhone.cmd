@echo off
setlocal
cd /d "%~dp0"
title ????????
"%~dp0tools\ModemVoicePhone.exe"
echo.
pause
