﻿<#
    Verify.ps1
    TOSHIBA PORTEGE M500 · Windows 10 x64 调制解调器驱动 —— 状态与功能验证（只读，不修改系统）

    用法（需要管理员权限以读取驱动库/注册表）：
        powershell -NoProfile -ExecutionPolicy Bypass -File .\Verify.ps1
        powershell -NoProfile -ExecutionPolicy Bypass -File .\Verify.ps1 -SkipAtTest

    退出码：0 = 全部关键项通过；1 = 存在失败项
#>
[CmdletBinding()]
param(
    [switch]$SkipAtTest
)

$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'ModemCommon.ps1')
Initialize-Log -Path (Join-Path $PSScriptRoot 'verify.log')

Write-Title 'TOSHIBA PORTEGE M500 · 调制解调器驱动验证'

$isAdmin = Test-IsAdmin
$checks = New-Object System.Collections.ArrayList

function Add-Check {
    param([string]$Name, [bool]$Pass, [string]$Detail = '')
    $null = $checks.Add([pscustomobject]@{ Name = $Name; Pass = $Pass; Detail = $Detail })
    $tag = if ($Pass) { '[通过]' } else { '[失败]' }
    $color = if ($Pass) { 'Green' } else { 'Red' }
    Write-Log ($tag + ' ' + $Name + $(if ($Detail) { '  —— ' + $Detail } else { '' })) $color
}

Write-Log ('管理员权限: ' + $(if ($isAdmin) { '是' } else { '否（部分项可能读不到，建议以管理员运行）' }))

# ---------------------------------------------------------------- 1. 系统
$os = Get-CimInstance Win32_OperatingSystem
Write-Log ('操作系统: ' + $os.Caption + ' ' + $os.Version + ' ' + $os.OSArchitecture)
$isWin10x64 = ($os.Version -like '10.*') -and ($os.OSArchitecture -like '*64*')
Add-Check 'Windows 10 x64 平台' $isWin10x64 ($os.Caption + ' ' + $os.Version + ' ' + $os.OSArchitecture)

# ---------------------------------------------------------------- 2. 驱动包
$drvDir  = Join-Path $PSScriptRoot 'driver'
$catPath = Join-Path $drvDir 'lsimdv64.cat'
$infPath = Join-Path $drvDir 'lsimdv64.inf'
$loadSrc = Join-Path $drvDir $script:LoadFile
$vendorSrc = Join-Path $drvDir $script:VendorFile

$pkgOk = (Test-Path -LiteralPath $catPath) -and (Test-Path -LiteralPath $infPath) -and (Test-Path -LiteralPath $loadSrc)
Add-Check '驱动包文件齐全' $pkgOk $drvDir

if (Test-Path -LiteralPath $catPath) {
    $sig = Get-AuthenticodeSignature -LiteralPath $catPath
    Add-Check 'WHQL 目录签名有效' ($sig.Status -eq 'Valid') (($sig.Status.ToString()) + ' / ' + $(if ($sig.SignerCertificate) { $sig.SignerCertificate.Subject } else { '' }))
}

# ---------------------------------------------------------------- 3. 设备
$dev = Get-ModemDevice
if (-not $dev) {
    Add-Check '调制解调器设备存在' $false '未找到 HDAUDIO\FUNC_02&VEN_11C1&DEV_3026'
} else {
    Add-Check '调制解调器设备存在' $true $dev.InstanceId
    Write-Log ('设备名称: ' + $dev.FriendlyName)
    Add-Check '设备状态正常 (OK / CM_PROB_NONE)' (($dev.Status -eq 'OK') -and ($dev.Problem -eq 'CM_PROB_NONE')) ($dev.Status + ' / ' + $dev.Problem)

    $prov = Get-DeviceProperty $dev 'DEVPKEY_Device_DriverProvider'
    $ver  = Get-DeviceProperty $dev 'DEVPKEY_Device_DriverVersion'
    $dinf = Get-DeviceProperty $dev 'DEVPKEY_Device_DriverInfPath'
    $svc  = Get-DeviceProperty $dev 'DEVPKEY_Device_Service'
    Write-Log ('驱动提供者: ' + $prov + '   版本: ' + $ver + '   INF: ' + $dinf + '   服务: ' + $svc)
    Add-Check '驱动提供者为 LSI' ($prov -eq 'LSI') ([string]$prov)
    Add-Check '驱动版本为 2.2.97' ([string]$ver -like '2.2.97*') ([string]$ver)
}

# ---------------------------------------------------------------- 4. 服务与加载文件名
if (-not (Test-ServiceExists)) {
    Add-Check '内核服务 AgereSoftModem 已注册' $false '服务不存在'
} else {
    Add-Check '内核服务 AgereSoftModem 已注册' $true ''
    $ip = Get-ServiceImagePath
    Write-Log ('服务 ImagePath: ' + $ip)
    Add-Check ('ImagePath 指向 ' + $script:LoadFile) ([string]$ip -like ('*' + $script:LoadFile)) ([string]$ip)

    $svcObj = Get-Service -Name $script:SvcName -ErrorAction SilentlyContinue
    if ($svcObj) {
        Add-Check '服务已启动 (RUNNING)' ($svcObj.Status -eq 'Running') ($svcObj.Status.ToString())
    }

    $loaded = Get-CimInstance Win32_SystemDriver -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq $script:SvcName }
    if ($loaded) {
        Write-Log ('已加载镜像: ' + $loaded.PathName + '  状态: ' + $loaded.State)
        Add-Check '实际加载的镜像为 tosm500md.sys' ([string]$loaded.PathName -like ('*' + $script:LoadFile)) ([string]$loaded.PathName)
    }

    # 已加载文件与包内文件哈希是否一致
    $installedPath = Join-Path $env:SystemRoot ('System32\drivers\' + $script:LoadFile)
    $h1 = Get-FileSha256 $installedPath
    $h2 = Get-FileSha256 $loadSrc
    if ($h1 -and $h2) {
        Add-Check '已安装二进制与包内一致' ($h1 -eq $h2) ($h1.Substring(0, 16) + '...')
    } else {
        Add-Check '已安装二进制与包内一致' $false ('文件缺失: ' + $installedPath)
    }
}

# ---------------------------------------------------------------- 5. 串口
$port = Get-ModemPortName
$allPorts = @([System.IO.Ports.SerialPort]::GetPortNames())
Write-Log ('系统串口: ' + $(if ($allPorts.Count) { $allPorts -join ', ' } else { '<无>' }) + '    调制解调器串口: ' + $(if ($port) { $port } else { '<未找到>' }))
Add-Check '调制解调器串口已分配' ([bool]$port) ([string]$port)

# ---------------------------------------------------------------- 6. AT 功能自检
if (-not $SkipAtTest) {
    Write-Log '正在执行 AT 指令自检……'
    $t = Test-ModemAt -PortName $port -Commands @('AT', 'ATI', 'AT+FMI', 'AT+FMM', 'AT+FMR', 'AT+FCLASS=?')
    if (-not $t.Opened) {
        Add-Check '串口 AT 通信' $false ([string]$t.Error)
    } else {
        foreach ($r in $t.Responses) { Write-Log ('    ' + $r.Command.PadRight(12) + ' -> ' + $r.Raw) }
        Add-Check '串口 AT 通信' $t.Ok ''
        $idResp = ($t.Responses | Where-Object { $_.Command -eq 'ATI' }).Raw
        Add-Check '调制解调器固件可识别' ([string]$idResp -match 'TOSHIBA Software Modem') ([string]$idResp)
        $fmi = ($t.Responses | Where-Object { $_.Command -eq 'AT+FMI' }).Raw
        Add-Check '厂商信息 (AT+FMI)' ([string]$fmi -match 'LSI') ([string]$fmi)

        # 拨号音检测（无电话线时返回 NO DIALTONE 属正常，能返回即说明 DAA 已动作）
        $dial = Test-ModemAt -PortName $port -Commands @('ATX4DT0', 'ATH') -PerCommandTimeoutMs 20000
        $dialResp = ($dial.Responses | Where-Object { $_.Command -eq 'ATX4DT0' }).Raw
        Write-Log ('    摘机/拨号音检测 -> ' + $dialResp)
        $daaOk = ([string]$dialResp -match 'NO DIAL|NO DIALTONE|NO CARRIER|BUSY|NO ANSWER|CONNECT')
        Add-Check 'DAA 摘机与拨号音检测通路' $daaOk ([string]$dialResp)
    }
} else {
    Write-Log '已跳过 AT 自检（-SkipAtTest）' Yellow
}

# ---------------------------------------------------------------- 7. 结论
Write-Title '验证结论'
$failed = @($checks | Where-Object { -not $_.Pass })
Write-Host ''
$checks | ForEach-Object {
    $tag = if ($_.Pass) { '通过' } else { '失败' }
    $color = if ($_.Pass) { 'Green' } else { 'Red' }
    Write-Host ('  [{0}] {1,-38} {2}' -f $tag, $_.Name, $_.Detail) -ForegroundColor $color
}
Write-Host ''
if ($failed.Count -eq 0) {
    Write-Log ('全部 ' + $checks.Count + ' 项检查通过 —— 调制解调器驱动工作正常。') Green
    exit 0
} else {
    Write-Log ('共 ' + $failed.Count + ' 项失败（总 ' + $checks.Count + ' 项）。请运行 Install.cmd 修复。') Red
    exit 1
}
