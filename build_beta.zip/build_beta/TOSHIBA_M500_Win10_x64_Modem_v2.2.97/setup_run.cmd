@echo off
cd /d "%~dp0"
if not exist "%~dp0Setup.cmd" exit /b 9
set "PN=%SystemRoot%\System32\pnputil.exe"
echo [pass 1/2] installing driver ...
call "%~dp0Setup.cmd" <nul
echo [scan] forcing device re-enumeration ...
"%PN%" /scan-devices >nul 2>&1
echo [pass 2/2] re-binding device to the new driver ...
call "%~dp0Setup.cmd" <nul
echo [scan] forcing device re-enumeration ...
"%PN%" /scan-devices >nul 2>&1
reg query "HKLM\SYSTEM\CurrentControlSet\Services\AgereSoftModem" /v ImagePath >nul 2>&1
if not errorlevel 1 exit /b 0
echo [pass 3/3] service still missing, retrying ...
call "%~dp0Setup.cmd" <nul
"%PN%" /scan-devices >nul 2>&1
reg query "HKLM\SYSTEM\CurrentControlSet\Services\AgereSoftModem" /v ImagePath >nul 2>&1
if not errorlevel 1 exit /b 0
exit /b 4