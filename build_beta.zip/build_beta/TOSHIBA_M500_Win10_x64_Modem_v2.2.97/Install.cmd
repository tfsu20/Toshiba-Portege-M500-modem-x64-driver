@echo off
setlocal
cd /d "%~dp0"
title TOSHIBA PORTEGE M500 - Modem Driver - Install
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo.
    echo   Administrator privileges are required.
    echo   A UAC prompt will appear now - please click "Yes".
    echo.
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -WorkingDirectory '%~dp0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1" %*
set RC=%errorlevel%
echo.
echo   Exit code: %RC%
pause
exit /b %RC%
