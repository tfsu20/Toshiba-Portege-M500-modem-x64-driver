﻿<#  Win7/8/10/11 x64 通用：把 AgereSoftModem 服务的 ImagePath 指向未被拦截的 tosm500md.sys
    用法（管理员）：powershell -ExecutionPolicy Bypass -File FixLoadName.ps1                     #>
$ErrorActionPreference = 'Stop'
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host '需要管理员权限，请右键以管理员身份运行 FixLoadName.cmd' -ForegroundColor Red; exit 1
}
$pkg = Split-Path -Parent $MyInvocation.MyCommand.Definition
$src = Join-Path $pkg 'driver\tosm500md.sys'
$dst = Join-Path $env:SystemRoot 'System32\drivers\tosm500md.sys'
if (-not (Test-Path $src)) { Write-Host "缺文件: $src" -ForegroundColor Red; exit 1 }
Copy-Item $src $dst -Force
$svc = 'HKLM:\SYSTEM\CurrentControlSet\Services\AgereSoftModem'
if (-not (Test-Path $svc)) { Write-Host '服务 AgereSoftModem 不存在，请先在设备管理器中安装 driver\lsimdv64.inf' -ForegroundColor Yellow; exit 1 }
Set-ItemProperty -Path $svc -Name ImagePath -Value '\SystemRoot\system32\DRIVERS\tosm500md.sys'
Write-Host ('ImagePath -> ' + (Get-ItemProperty $svc).ImagePath) -ForegroundColor Green
# 重启设备（Win7 无 pnputil /restart-device，用 devcon 或直接禁用/启用）
$inst = $null
$base = 'HKLM:\SYSTEM\CurrentControlSet\Enum\HDAUDIO'
if (Test-Path $base) {
    Get-ChildItem $base | Where-Object { $_.PSChildName -like 'FUNC_02&VEN_11C1&DEV_3026*' } | ForEach-Object {
        Get-ChildItem $_.PSPath | ForEach-Object { $inst = ($_.Name -replace '^HKEY_LOCAL_MACHINE\\', 'HKLM:\') }
    }
}
if ($inst) {
    $pn = Join-Path $env:SystemRoot 'System32\pnputil.exe'
    & $pn /restart-device $inst 2>$null
    if ($LASTEXITCODE -ne 0) { Write-Host 'Win7: 请在设备管理器中「禁用/启用」TOSHIBA Software Modem 以生效' -ForegroundColor Yellow }
}
Write-Host '完成。若设备仍无法启动，请重启一次系统。' -ForegroundColor Green
