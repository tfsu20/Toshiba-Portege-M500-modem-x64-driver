@echo off
setlocal
cd /d "%~dp0"
title TOSHIBA PORTEGE M500 - Modem Driver - Uninstall
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo.
    echo   Administrator privileges are required.
    echo   A UAC prompt will appear now - please click "Yes".
    echo.
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -WorkingDirectory '%~dp0' -Verb RunAs"
    exit /b
)
echo.
echo   This will remove the modem driver. The device will return to
echo   Microsoft's "Win Modem (Unsupported)" state (problem code 48).
echo.
choice /c YN /m "Continue"
if errorlevel 2 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall.ps1" %*
set RC=%errorlevel%
echo.
echo   Exit code: %RC%
pause
exit /b %RC%
