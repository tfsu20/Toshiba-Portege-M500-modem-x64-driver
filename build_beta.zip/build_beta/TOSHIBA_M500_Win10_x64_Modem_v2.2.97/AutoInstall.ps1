﻿# AutoInstall.ps1 - Win7 x64 ~ Win11 x64 自动安装（驱动 + 桌面快捷方式）
$ErrorActionPreference = 'Continue'
$here = Split-Path -Parent $MyInvocation.MyCommand.Definition
function Log($m, $c) { if (-not $c) { $c = 'Gray' }; Write-Host $m -ForegroundColor $c }

$id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Log '需要管理员权限' 'Red'; exit 1
}
$os = [Environment]::OSVersion.Version
Log ('系统: ' + [Environment]::OSVersion.VersionString + '  x64=' + [Environment]::Is64BitOperatingSystem)

# 1) 桌面快捷方式
$exe = Join-Path $here 'tools\ModemVoicePhone.exe'
if (Test-Path $exe) {
    $desk = [Environment]::GetFolderPath('CommonDesktopDirectory')
    if (-not $desk) { $desk = Join-Path $env:PUBLIC 'Desktop' }
    $lnk = Join-Path $desk 'TOSHIBA Modem Dialer.lnk'
    try {
        $ws = New-Object -ComObject WScript.Shell
        $sc = $ws.CreateShortcut($lnk)
        $sc.TargetPath = $exe
        $sc.WorkingDirectory = (Split-Path $exe -Parent)
        $sc.IconLocation = (Join-Path $env:SystemRoot 'System32\shell32.dll') + ',20'
        $sc.Description = 'TOSHIBA Software Modem 拨号控制台'
        $sc.Save()
        Log ('桌面快捷方式: ' + $lnk) 'Green'
    } catch { Log ('快捷方式失败: ' + $_.Exception.Message) 'Yellow' }
}

# 2) 设备实例
$inst = $null
$base = 'HKLM:\SYSTEM\CurrentControlSet\Enum\HDAUDIO'
if (Test-Path $base) {
    foreach ($d in (Get-ChildItem $base -ErrorAction SilentlyContinue)) {
        if ($d.PSChildName -like 'FUNC_02&VEN_11C1&DEV_3026*') {
            foreach ($i in (Get-ChildItem $d.PSPath -ErrorAction SilentlyContinue)) {
                if (-not $inst) { $inst = $d.PSChildName + '\' + $i.PSChildName }
            }
        }
    }
}
Log ('设备实例: ' + $(if ($inst) { $inst } else { '未找到' }))

# 3) 导入驱动：一次尝试，按系统选对语法，看到成功字样即判定成功
$inf = Join-Path $here 'driver\lsimdv64.inf'
$pn = Join-Path $env:SystemRoot 'System32\pnputil.exe'
$newSyntax = ($os.Major -gt 6) -or ($os.Major -eq 6 -and $os.Minor -ge 2)
if ($newSyntax) { Log ('pnputil /add-driver ... /install'); $out = & $pn /add-driver $inf /install 2>&1 }
else { Log ('pnputil -a ... -i   (Windows 7 语法)'); $out = & $pn -a $inf -i 2>&1 }
foreach ($line in @($out)) { if ("$line".Trim()) { Log ('  ' + $line) 'DarkGray' } }
$txt = (@($out) -join "`n")
$importOk = ($txt -match '(?i)successfully|up-to-date|added successfully')
Log ('驱动导入: ' + $(if ($importOk) { '成功' } else { '未确认，见上方输出' })) $(if ($importOk) { 'Green' } else { 'Yellow' })

# 4) 加载名重定向
$sysSrc = Join-Path $here 'driver\tosm500md.sys'
$sysDst = Join-Path $env:SystemRoot 'System32\drivers\tosm500md.sys'
if (Test-Path $sysSrc) {
    try { Copy-Item $sysSrc $sysDst -Force -ErrorAction Stop; Log ('已部署 ' + $sysDst) 'Green' }
    catch {
        if ((Test-Path $sysDst) -and ((Get-Item $sysDst).Length -eq (Get-Item $sysSrc).Length)) { Log '驱动文件已存在（加载中），无需替换' 'Green' }
        else { Log ('复制失败: ' + $_.Exception.Message) 'Yellow' }
    }
}
$svc = 'HKLM:\SYSTEM\CurrentControlSet\Services\AgereSoftModem'
if (Test-Path $svc) {
    Set-ItemProperty -Path $svc -Name ImagePath -Value '\SystemRoot\system32\DRIVERS\tosm500md.sys'
    Log ('ImagePath -> ' + (Get-ItemProperty $svc).ImagePath) 'Green'
} else { Log '服务未创建：请用设备管理器手动安装 driver\lsimdv64.inf，再运行 FixLoadName.cmd' 'Yellow' }

# 5) Agere 音频配置
try {
    $ag = 'HKLM:\SOFTWARE\Agere\SoftModem'
    if (-not (Test-Path $ag)) { New-Item -Path $ag -Force | Out-Null }
    Set-ItemProperty -Path $ag -Name 'AGRSMSetup' -Value ([byte[]](0,8,0xC6,0x84)) -Type Binary
    $dv = Join-Path $ag 'DCPSpeakerVolume'
    if (-not (Test-Path $dv)) { New-Item -Path $dv -Force | Out-Null }
    Set-ItemProperty -Path $dv -Name 'SpeakerVolumeScale' -Value ([byte[]](0x32)) -Type Binary
    $dos = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\DOS Devices'
    if (Test-Path $dos) { New-ItemProperty -Path $dos -Name 'AGRSM' -Value '\Device\AGRSM_xface' -PropertyType String -Force | Out-Null }
    Log 'Agere 音频配置已写入' 'Green'
} catch { Log ('Agere 配置失败: ' + $_.Exception.Message) 'Yellow' }

# 6) 启动服务 / 重启设备
Start-Service AgereSoftModem -ErrorAction SilentlyContinue
Start-Service AgereModemAudio -ErrorAction SilentlyContinue
if ($inst) {
    if ($newSyntax) { & $pn /restart-device $inst 2>&1 | Out-Null }
    try {
        $w = Get-WmiObject Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.DeviceID -eq $inst } | Select-Object -First 1
        if ($w -and $w.ConfigManagerErrorCode -ne 0) { $w.Disable() | Out-Null; Start-Sleep -Seconds 2; $w.Enable() | Out-Null; Log '已用 WMI 重启设备' 'Green' }
    } catch { }
}

# 7) 结果
$dev = Get-WmiObject Win32_PnPEntity -ErrorAction SilentlyContinue | Where-Object { $_.DeviceID -like 'HDAUDIO\FUNC_02&VEN_11C1&DEV_3026*' } | Select-Object -First 1
if ($dev) {
    Log ('设备: ' + $dev.Name + '   ErrorCode=' + $dev.ConfigManagerErrorCode) 'Green'
    if ($dev.ConfigManagerErrorCode -eq 0) { Log '驱动工作正常。' 'Green' } else { Log '设备有错误码；若为 48 请运行 FixLoadName.cmd 后禁用/启用设备。' 'Yellow' }
} else { Log '未检测到调制解调器设备。' 'Yellow' }
Log '完成。桌面已生成 "TOSHIBA Modem Dialer" 快捷方式。' 'Cyan'
exit 0