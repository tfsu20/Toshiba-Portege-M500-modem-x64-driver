﻿<#
    ModemCommon.ps1
    TOSHIBA PORTEGE M500 / Windows 10 x64 内置调制解调器驱动 —— 公共函数库
    由 Install.ps1 / Verify.ps1 / Uninstall.ps1 点源(dot-source)加载。

    说明：本机（以及部分安装了驱动保护/安全软件的机器）在驱动加载层面对文件名
    "agrsm64.sys" 存在拦截，因此把 LSI 官方 WHQL 二进制以另一个文件名
    "tosm500md.sys" 落盘并加载。文件内容、SHA-256 与 WHQL 目录签名均不变。
#>

$script:SvcName    = 'AgereSoftModem'
$script:VendorFile = 'agrsm64.sys'
$script:LoadFile   = 'tosm500md.sys'
$script:HwIdMatch  = @('HDAUDIO\FUNC_02&VEN_11C1&DEV_3026', 'PCI\VEN_11C1&DEV_3026')
$script:ClassGuid  = '{4D36E96D-E325-11CE-BFC1-08002BE10318}'
$script:LogFile    = $null

function Initialize-Log {
    param([Parameter(Mandatory)][string]$Path)
    $script:LogFile = $Path
    try { if (Test-Path -LiteralPath $Path) { Remove-Item -LiteralPath $Path -Force } } catch {}
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('Gray','Green','Yellow','Red','Cyan','White','DarkGray')][string]$Color = 'Gray'
    )
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Message
    Write-Host $line -ForegroundColor $Color
    if ($script:LogFile) { try { Add-Content -LiteralPath $script:LogFile -Value $line -Encoding UTF8 } catch {} }
}

function Write-Title {
    param([string]$Text)
    Write-Host ''
    Write-Host ('=' * 78) -ForegroundColor DarkCyan
    Write-Host ('  ' + $Text) -ForegroundColor White
    Write-Host ('=' * 78) -ForegroundColor DarkCyan
    if ($script:LogFile) {
        try {
            Add-Content -LiteralPath $script:LogFile -Value '' -Encoding UTF8
            Add-Content -LiteralPath $script:LogFile -Value ('=' * 78) -Encoding UTF8
            Add-Content -LiteralPath $script:LogFile -Value ('  ' + $Text) -Encoding UTF8
            Add-Content -LiteralPath $script:LogFile -Value ('=' * 78) -Encoding UTF8
        } catch {}
    }
}

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $pr = New-Object Security.Principal.WindowsPrincipal($id)
    return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-ModemDevice {
    # 返回本机 LSI/Agere HDA 调制解调器设备对象；找不到返回 $null
    $devs = @()
    try { $devs = @(Get-PnpDevice -PresentOnly -ErrorAction Stop) } catch {}
    if (-not $devs) { try { $devs = @(Get-PnpDevice -ErrorAction Stop) } catch {} }
    foreach ($d in $devs) {
        foreach ($prefix in $script:HwIdMatch) {
            if ($d.InstanceId -like ($prefix + '*')) { return $d }
        }
    }
    return $null
}

function Get-DeviceProperty {
    param($Device, [string]$KeyName)
    if (-not $Device) { return $null }
    try { return (Get-PnpDeviceProperty -InstanceId $Device.InstanceId -KeyName $KeyName -ErrorAction Stop).Data } catch { return $null }
}

function Get-ServiceImagePath {
    param([string]$Name = $script:SvcName)
    $p = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $Name
    if (-not (Test-Path -LiteralPath $p)) { return $null }
    $v = Get-ItemProperty -LiteralPath $p -Name ImagePath -ErrorAction SilentlyContinue
    if ($v) { return $v.ImagePath }
    return $null
}

function Set-ServiceImagePath {
    param([string]$Value, [string]$Name = $script:SvcName)
    $p = 'HKLM:\SYSTEM\CurrentControlSet\Services\' + $Name
    Set-ItemProperty -LiteralPath $p -Name ImagePath -Value $Value
}

function Test-ServiceExists {
    param([string]$Name = $script:SvcName)
    return (Test-Path -LiteralPath ('HKLM:\SYSTEM\CurrentControlSet\Services\' + $Name))
}

function Get-ModemPortName {
    # 优先用「调制解调器」类注册表里的 AttachedTo，其次取系统串口列表中第一个
    $cm = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\' + $script:ClassGuid
    if (Test-Path -LiteralPath $cm) {
        foreach ($sub in (Get-ChildItem -LiteralPath $cm -ErrorAction SilentlyContinue)) {
            $props = Get-ItemProperty -LiteralPath $sub.PSPath -ErrorAction SilentlyContinue
            if (-not $props) { continue }
            if ($props.AttachedTo -and ($props.MatchingDeviceId -like '*VEN_11C1&DEV_3026*')) {
                return [string]$props.AttachedTo
            }
        }
    }
    $ports = @([System.IO.Ports.SerialPort]::GetPortNames())
    if ($ports.Count -gt 0) { return [string]$ports[0] }
    return $null
}

function Wait-Until {
    param(
        [Parameter(Mandatory)][scriptblock]$Condition,
        [int]$TimeoutSec = 30,
        [int]$IntervalMs = 500
    )
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        $r = $null
        try { $r = & $Condition } catch {}
        if ($r) { return $r }
        Start-Sleep -Milliseconds $IntervalMs
    }
    return $null
}

function Get-PublishedInfName {
    # 在驱动库中按「原始 INF 文件名」反查已发布的 oemNN.inf 名称（与系统语言无关）
    param([string]$OriginalInfName = 'lsimdv64.inf')
    $pnputil = Join-Path $env:SystemRoot 'System32\pnputil.exe'
    $text = ''
    try { $text = (& $pnputil /enum-drivers 2>&1 | Out-String) } catch { return $null }
    $lines = $text -split "`r?`n"
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match [regex]::Escape($OriginalInfName)) {
            for ($j = $i; $j -ge 0; $j--) {
                if ($lines[$j] -match '(oem\d+\.inf)') { return $Matches[1] }
            }
        }
    }
    return $null
}

function Test-ModemAt {
    # 串口 AT 指令自检；返回对象含 Opened / Ok / Responses / Error
    param(
        [string]$PortName,
        [string[]]$Commands = @('AT', 'ATI', 'AT+FMI', 'AT+FMM', 'AT+FMR'),
        [int]$PerCommandTimeoutMs = 2500
    )
    $result = [pscustomobject]@{
        Port      = $PortName
        Opened    = $false
        Ok        = $false
        Responses = @()
        Error     = $null
    }
    if (-not $PortName) {
        $result.Error = '未找到调制解调器串口'
        return $result
    }
    $sp = $null
    try {
        $sp = New-Object System.IO.Ports.SerialPort($PortName, 115200, [System.IO.Ports.Parity]::None, 8, [System.IO.Ports.StopBits]::One)
        $sp.ReadTimeout = 1000
        $sp.WriteTimeout = 1500
        $sp.DtrEnable = $true
        $sp.RtsEnable = $true
        $sp.Handshake = [System.IO.Ports.Handshake]::None
        $sp.Open()
        $result.Opened = $true
        Start-Sleep -Milliseconds 400
        foreach ($cmd in $Commands) {
            try { $sp.DiscardInBuffer() } catch {}
            $sp.Write($cmd + "`r")
            $buf = ''
            $deadline = (Get-Date).AddMilliseconds($PerCommandTimeoutMs)
            while ((Get-Date) -lt $deadline) {
                try { $buf += $sp.ReadExisting() } catch {}
                if ($buf -match 'OK|ERROR|NO DIAL|NO CARRIER|NO ANSWER|BUSY|CONNECT') {
                    Start-Sleep -Milliseconds 150
                    try { $buf += $sp.ReadExisting() } catch {}
                    break
                }
                Start-Sleep -Milliseconds 50
            }
            $clean = ($buf -replace "`r", '' -replace "`n", ' ').Trim()
            $result.Responses += [pscustomobject]@{ Command = $cmd; Raw = $clean }
        }
        $okCount = @($result.Responses | Where-Object { $_.Raw -match 'OK' }).Count
        $result.Ok = ($okCount -ge 1)
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        if ($sp) {
            try { if ($sp.IsOpen) { $sp.Close() } } catch {}
            try { $sp.Dispose() } catch {}
        }
    }
    return $result
}

function Get-FileSha256 {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash } catch { return $null }
}

function Add-PendingFileDelete {
    # 登记「重启后删除」（驱动文件正被加载时无法立即删除）
    param([Parameter(Mandatory)][string]$Path)
    $k = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
    $cur = (Get-ItemProperty -LiteralPath $k -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
    if ($cur) { $cur = @($cur) } else { $cur = @() }
    if (($cur -join "`n") -match [regex]::Escape($Path)) { return $false }
    $cur += ('\??\' + $Path)
    $cur += ''
    Set-ItemProperty -LiteralPath $k -Name PendingFileRenameOperations -Value $cur -Type MultiString
    return $true
}

function Remove-PendingFileDelete {
    # 撤销「重启后删除」登记。
    # 卸载后不重启就直接重装时必须调用，否则下次启动会删掉正在使用的驱动文件。
    param([Parameter(Mandatory)][string]$Path)
    $k = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
    $cur = (Get-ItemProperty -LiteralPath $k -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
    if (-not $cur) { return $false }
    $cur = @($cur)
    $removed = $false
    $out = @()
    for ($i = 0; $i -lt $cur.Count; $i += 2) {
        $src = [string]$cur[$i]
        $dst = ''
        if (($i + 1) -lt $cur.Count) { $dst = [string]$cur[$i + 1] }
        if ($src -like ('*' + $Path)) { $removed = $true; continue }
        $out += $src
        $out += $dst
    }
    if ($removed) {
        if ($out.Count -gt 0) {
            Set-ItemProperty -LiteralPath $k -Name PendingFileRenameOperations -Value $out -Type MultiString
        } else {
            Remove-ItemProperty -LiteralPath $k -Name PendingFileRenameOperations -ErrorAction SilentlyContinue
        }
    }
    return $removed
}
