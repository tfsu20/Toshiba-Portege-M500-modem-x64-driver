﻿<#
    Uninstall.ps1
    TOSHIBA PORTEGE M500 · Windows 10 x64 调制解调器驱动 —— 卸载 / 回滚

    用法（需要管理员权限）：
        powershell -NoProfile -ExecutionPolicy Bypass -File .\Uninstall.ps1
            完整卸载：删除驱动包、去掉重定向文件，设备回到微软 "Win Modem (Unsupported)" 状态
        powershell -NoProfile -ExecutionPolicy Bypass -File .\Uninstall.ps1 -KeepPackage
            仅撤销文件名重定向（保留驱动库中的 LSI 驱动包），便于排查问题

    说明：卸载后调制解调器会重新回到「问题代码 48 / Win Modem (Unsupported)」，
          这是 Windows 10 对这块 2006 年硬件的出厂默认状态，属预期结果。
#>
[CmdletBinding()]
param(
    [switch]$KeepPackage
)

$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'ModemCommon.ps1')
Initialize-Log -Path (Join-Path $PSScriptRoot 'uninstall.log')

Write-Title 'TOSHIBA PORTEGE M500 · 调制解调器驱动卸载'

if (-not (Test-IsAdmin)) {
    Write-Log '错误：需要管理员权限。请右键以管理员身份运行 Uninstall.cmd。' Red
    exit 1
}

$dev = Get-ModemDevice
if ($dev) { Write-Log ('设备: ' + $dev.FriendlyName + '  状态: ' + $dev.Status + ' / ' + $dev.Problem) }
else { Write-Log '未找到调制解调器设备（继续执行清理）。' Yellow }

# ---------------------------------------------------------------- 1. 停止服务
if (Test-ServiceExists) {
    $svc = Get-Service -Name $script:SvcName -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq 'Running') {
        Write-Log '正在停止服务……'
        try { Stop-Service -Name $script:SvcName -Force -ErrorAction Stop; Write-Log '服务已停止' } catch { Write-Log ('停止服务失败（设备占用属正常）：' + $_.Exception.Message) Yellow }
    }
}

# ---------------------------------------------------------------- 2. 还原 ImagePath 为厂商原始文件名
if (Test-ServiceExists) {
    $vendorPath = '\SystemRoot\system32\DRIVERS\' + $script:VendorFile
    Set-ServiceImagePath -Value $vendorPath
    Write-Log ('服务 ImagePath 已还原为: ' + $vendorPath)
}

# ---------------------------------------------------------------- 3. 删除重定向用的二进制
$target = Join-Path $env:SystemRoot ('System32\drivers\' + $script:LoadFile)
if (Test-Path -LiteralPath $target) {
    try {
        Remove-Item -LiteralPath $target -Force -ErrorAction Stop
        Write-Log ('已删除: ' + $target)
    } catch {
        Write-Log ('文件正被占用，将在重启后删除: ' + $target) Yellow
        $k = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
        $cur = (Get-ItemProperty -LiteralPath $k -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
        if (-not $cur) { $cur = @() } else { $cur = @($cur) }
        if (-not ($cur -match [regex]::Escape($target))) {
            $cur += ('\??\' + $target)
            $cur += ''
            Set-ItemProperty -LiteralPath $k -Name PendingFileRenameOperations -Value $cur -Type MultiString
            Write-Log '已登记重启后删除（PendingFileRenameOperations）'
        }
    }
}

# ---------------------------------------------------------------- 4. 删除驱动包
if (-not $KeepPackage) {
    $pub = Get-PublishedInfName -OriginalInfName 'lsimdv64.inf'
    if ($pub) {
        Write-Log ('正在从驱动库删除驱动包: ' + $pub)
        $pnputil = Join-Path $env:SystemRoot 'System32\pnputil.exe'
        $out = & $pnputil /delete-driver $pub /uninstall /force 2>&1
        foreach ($line in @($out)) { if ("$line".Trim()) { Write-Log ('    ' + $line) DarkGray } }
        Write-Log ('pnputil 退出码: ' + $LASTEXITCODE)
    } else {
        Write-Log '驱动库中未找到 lsimdv64.inf 包（可能已被删除）。' Yellow
    }
} else {
    Write-Log '已指定 -KeepPackage：保留驱动库中的 LSI 驱动包。' Yellow
}

# ---------------------------------------------------------------- 5. 重启设备
if ($dev) {
    Write-Log '正在重启调制解调器设备……'
    $pnputil = Join-Path $env:SystemRoot 'System32\pnputil.exe'
    $out = & $pnputil /restart-device $dev.InstanceId 2>&1
    foreach ($line in @($out)) { if ("$line".Trim()) { Write-Log ('    ' + $line) DarkGray } }
    Start-Sleep -Seconds 3
    $d = Get-ModemDevice
    if ($d) { Write-Log ('卸载后设备状态: ' + $d.Status + ' / ' + $d.Problem + ' （48 = CM_PROB_DRIVER_BLOCKED，属出厂预期）') }
}

Write-Title '卸载完成'
Write-Log '如需重新安装，运行 Install.cmd 即可。' Green
exit 0
