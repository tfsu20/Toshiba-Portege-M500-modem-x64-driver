﻿<#
    Install.ps1
    TOSHIBA PORTEGE M500 · Windows 10 x64 内置调制解调器（LSI/Agere SV92PP HDA）驱动安装

    用法（需要管理员权限）：
        powershell -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1
        powershell -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 -Force        # 强制重新导入驱动包
        powershell -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 -SkipAtTest   # 跳过 AT 指令自检

    本脚本可重复运行（幂等）：驱动被重装、回滚或系统更新覆盖后，重新运行即可修复。
#>
[CmdletBinding()]
param(
    [switch]$Force,
    [switch]$SkipAtTest
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'ModemCommon.ps1')
Initialize-Log -Path (Join-Path $PSScriptRoot 'install.log')

Write-Title 'TOSHIBA PORTEGE M500 · Windows 10 x64 调制解调器驱动安装'
Write-Log ('脚本目录: ' + $PSScriptRoot)
Write-Log ('操作系统: ' + (Get-CimInstance Win32_OperatingSystem).Caption + '  ' + (Get-CimInstance Win32_OperatingSystem).Version + '  ' + $env:PROCESSOR_ARCHITECTURE)

# ---------------------------------------------------------------- 0. 权限检查
if (-not (Test-IsAdmin)) {
    Write-Log '错误：需要管理员权限。请右键以管理员身份运行 Install.cmd。' Red
    exit 1
}
Write-Log '管理员权限：已确认' Green

# ---------------------------------------------------------------- 1. 检查驱动包完整性
$drvDir = Join-Path $PSScriptRoot 'driver'
$infPath = Join-Path $drvDir 'lsimdv64.inf'
$catPath = Join-Path $drvDir 'lsimdv64.cat'
$loadSrc = Join-Path $drvDir $script:LoadFile
$vendorSrc = Join-Path $drvDir $script:VendorFile

$required = @($infPath, $catPath, $loadSrc, $vendorSrc,
              (Join-Path $drvDir 'agr64svc.exe'), (Join-Path $drvDir 'agrsco64.dll'),
              (Join-Path $drvDir 'agrsmdel.exe'), (Join-Path $drvDir 'agrdel64.exe'),
              (Join-Path $drvDir 'agrsmdel.ico'))
$missing = @($required | Where-Object { -not (Test-Path -LiteralPath $_) })
if ($missing.Count -gt 0) {
    Write-Log '错误：驱动包文件不完整，缺少：' Red
    $missing | ForEach-Object { Write-Log ('    ' + $_) Red }
    exit 1
}
if ((Get-FileSha256 $loadSrc) -ne (Get-FileSha256 $vendorSrc)) {
    Write-Log '错误：tosm500md.sys 与 agrsm64.sys 内容不一致（包已损坏）。' Red
    exit 1
}
Write-Log '驱动包完整性：通过（9 个文件齐全，二进制哈希一致）' Green

# ---------------------------------------------------------------- 2. 定位设备
$dev = Get-ModemDevice
if (-not $dev) {
    Write-Log '错误：未找到 LSI/Agere HDA 调制解调器设备。' Red
    Write-Log '       期望硬件 ID: HDAUDIO\FUNC_02&VEN_11C1&DEV_3026 （或 PCI\VEN_11C1&DEV_3026）' Red
    Write-Log '       请确认 BIOS 中 Modem 未被禁用，且设备管理器中存在该设备。' Red
    exit 1
}
Write-Log ('设备: ' + $dev.FriendlyName)
Write-Log ('实例: ' + $dev.InstanceId)

$hwIds = Get-DeviceProperty $dev 'DEVPKEY_Device_HardwareIds'
if ($hwIds) { Write-Log ('硬件 ID: ' + (@($hwIds) -join ' | ')) }

# ---------------------------------------------------------------- 3. 记录并显示当前状态
$prevProvider = Get-DeviceProperty $dev 'DEVPKEY_Device_DriverProvider'
$prevVersion  = Get-DeviceProperty $dev 'DEVPKEY_Device_DriverVersion'
$prevInf      = Get-DeviceProperty $dev 'DEVPKEY_Device_DriverInfPath'
Write-Log ('当前驱动: ' + $prevProvider + ' / ' + $prevVersion + ' / ' + $prevInf + ' / 状态 ' + $dev.Status + ' / 问题码 ' + $dev.Problem)

# ---------------------------------------------------------------- 4. 导入并安装 WHQL 驱动包
$needPackage = $true
if (-not $Force -and $prevProvider -eq 'LSI') {
    $needPackage = $false
    Write-Log '驱动包已是 LSI 官方版本，跳过导入（如需强制重装请加 -Force）' Yellow
}

if ($needPackage) {
    Write-Log '正在导入并安装 LSI/WHQL 驱动包（lsimdv64.inf）……'
    $pnputil = Join-Path $env:SystemRoot 'System32\pnputil.exe'
    $out = & $pnputil /add-driver $infPath /install 2>&1
    $pnputilExit = $LASTEXITCODE
    foreach ($line in @($out)) { if ("$line".Trim()) { Write-Log ('    ' + $line) DarkGray } }
    if ($pnputilExit -ne 0 -and $pnputilExit -ne 3010) {
        $nowProvider = Get-DeviceProperty (Get-ModemDevice) 'DEVPKEY_Device_DriverProvider'
        if ($nowProvider -eq 'LSI') {
            Write-Log ('pnputil 返回 ' + $pnputilExit + '，但设备已绑定 LSI 驱动，继续。') Yellow
        } else {
            Write-Log ('错误：驱动包安装失败（pnputil 退出码 ' + $pnputilExit + '）。') Red
            Write-Log '       请查看 driver 目录是否被安全软件拦截，或查看 C:\Windows\INF\setupapi.dev.log。' Red
            exit 1
        }
    } elseif ($pnputilExit -eq 3010) {
        Write-Log '驱动包安装：完成（系统提示需要重启以彻底生效，本驱动通常无需重启即可使用）' Green
    } else {
        Write-Log '驱动包安装：完成' Green
    }
}

# 安装完成后重新取一次设备对象
$dev = Get-ModemDevice

# ---------------------------------------------------------------- 5. 等待服务注册
$svcReady = Wait-Until -TimeoutSec 30 -Condition {
    if (Test-ServiceExists) { return $true }
    return $false
}
if (-not $svcReady) {
    Write-Log ('错误：服务 ' + $script:SvcName + ' 未注册成功，驱动包可能未正确安装。') Red
    exit 1
}
Write-Log ('服务 ' + $script:SvcName + '：已注册') Green

# ---------------------------------------------------------------- 6. 部署「实际加载名」二进制
#     背景：本机在驱动加载层对文件名 agrsm64.sys 有持久拦截（sc start 返回 1275）。
#     同一份二进制换名后可正常加载，且其 SHA-256 仍在 WHQL 目录签名内，签名校验照常通过。
$drvTarget = Join-Path $env:SystemRoot ('System32\drivers\' + $script:LoadFile)
$already = (Get-FileSha256 $drvTarget) -eq (Get-FileSha256 $loadSrc)
if (-not $already) {
    try {
        Copy-Item -LiteralPath $loadSrc -Destination $drvTarget -Force -ErrorAction Stop
        Write-Log ('已部署: ' + $drvTarget)
    } catch {
        Write-Log ('警告：复制 ' + $script:LoadFile + ' 失败（可能正被占用），尝试继续：' + $_.Exception.Message) Yellow
    }
} else {
    Write-Log ('已存在且哈希一致: ' + $drvTarget)
}

# 若之前跑过 Uninstall.ps1 但还没重启，该文件会被登记为「重启后删除」；这里必须撤销登记，
# 否则下次启动会把正在使用的驱动文件删掉，导致调制解调器无法加载。
if (Remove-PendingFileDelete -Path $drvTarget) {
    Write-Log '已撤销该文件原有的「重启后删除」登记' Yellow
}
if (Remove-PendingFileDelete -Path (Join-Path $env:SystemRoot ('System32\drivers\' + $script:VendorFile))) {
    Write-Log '已撤销 agrsm64.sys 的「重启后删除」登记' Yellow
}

$desired = '\SystemRoot\system32\DRIVERS\' + $script:LoadFile
$current = Get-ServiceImagePath
if ($current -ne $desired) {
    Set-ServiceImagePath -Value $desired
    Write-Log ('服务 ImagePath 已指向: ' + $desired)
} else {
    Write-Log ('服务 ImagePath 已正确: ' + $desired)
}
Write-Log ('服务 ImagePath 现值: ' + (Get-ServiceImagePath))

# ---------------------------------------------------------------- 7. 重启设备使其重新加载
Write-Log '正在重启调制解调器设备……'
$pnputil = Join-Path $env:SystemRoot 'System32\pnputil.exe'
$rout = & $pnputil /restart-device $dev.InstanceId 2>&1
foreach ($line in @($rout)) { if ("$line".Trim()) { Write-Log ('    ' + $line) DarkGray } }

$ok = Wait-Until -TimeoutSec 40 -Condition {
    $d = Get-ModemDevice
    if ($d -and $d.Status -eq 'OK' -and $d.Problem -eq 'CM_PROB_NONE') { return $d }
    return $false
}

if (-not $ok) {
    $d = Get-ModemDevice
    Write-Log ('错误：设备未能正常启动（状态 ' + $d.Status + ' / 问题码 ' + $d.Problem + '）。') Red
    Write-Log '       常见原因：安全软件（火绒/驱动保护类）拦截了新文件名的驱动加载。' Red
    Write-Log '       处理：把 C:\Windows\System32\drivers\tosm500md.sys 加入安全软件白名单后重试。' Red
    exit 1
}
Write-Log '设备启动：成功（状态 OK，问题码 CM_PROB_NONE）' Green

# ---------------------------------------------------------------- 8. AT 指令自检
if (-not $SkipAtTest) {
    $port = Get-ModemPortName
    Write-Log ('调制解调器串口: ' + $(if ($port) { $port } else { '<未找到>' }))
    if ($port) {
        Write-Log '正在执行 AT 指令自检……'
        $t = Test-ModemAt -PortName $port
        if ($t.Opened) {
            foreach ($r in $t.Responses) { Write-Log ('    ' + $r.Command.PadRight(12) + ' -> ' + $r.Raw) }
            if ($t.Ok) { Write-Log 'AT 自检：通过，调制解调器已响应' Green }
            else { Write-Log ('AT 自检：串口已打开但无有效响应 ' + $t.Error) Yellow }
        } else {
            Write-Log ('AT 自检：无法打开串口 ' + $port + ' ：' + $t.Error) Yellow
        }
    }
}

# ---------------------------------------------------------------- 9. 汇总
$dev = Get-ModemDevice
Write-Title '安装结果'
Write-Log ('设备名称  : ' + $dev.FriendlyName)
Write-Log ('设备状态  : ' + $dev.Status + ' / ' + $dev.Problem)
Write-Log ('驱动提供者: ' + (Get-DeviceProperty $dev 'DEVPKEY_Device_DriverProvider'))
Write-Log ('驱动版本  : ' + (Get-DeviceProperty $dev 'DEVPKEY_Device_DriverVersion') + '  (' + (Get-DeviceProperty $dev 'DEVPKEY_Device_DriverDate') + ')')
Write-Log ('驱动 INF  : ' + (Get-DeviceProperty $dev 'DEVPKEY_Device_DriverInfPath') + '  [' + (Get-PublishedInfName) + ']')
Write-Log ('服务      : ' + $script:SvcName + ' / ' + (Get-Service -Name $script:SvcName -ErrorAction SilentlyContinue).Status + ' / ' + (Get-ServiceImagePath))
Write-Log ('串口      : ' + $(if (Get-ModemPortName) { Get-ModemPortName } else { '<未找到>' }))
Write-Log ''
Write-Log '安装完成。若需验证请运行 Verify.cmd；若需撤销请运行 Uninstall.cmd。' Green
exit 0
