using System;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Threading;

public static class VoiceProbe
{
    private static SerialPort sp;

    private static string ReadLine(int timeoutMs)
    {
        StringBuilder sb = new StringBuilder();
        DateTime end = DateTime.Now.AddMilliseconds(timeoutMs);
        while (DateTime.Now < end)
        {
            if (sp.BytesToRead > 0)
            {
                int v = sp.ReadByte();
                if (v < 0) continue;
                char c = (char)v;
                if (c == '\n') { if (sb.Length > 0) return sb.ToString().Trim(); }
                else if (c != '\r') sb.Append(c);
            }
            else Thread.Sleep(3);
        }
        return sb.ToString().Trim();
    }

    private static string Cmd(string cmd, int timeoutMs)
    {
        try { sp.DiscardInBuffer(); } catch { }
        sp.Write(cmd + "\r");
        DateTime end = DateTime.Now.AddMilliseconds(timeoutMs);
        StringBuilder sb = new StringBuilder();
        while (DateTime.Now < end)
        {
            if (sp.BytesToRead > 0)
            {
                int v = sp.ReadByte();
                if (v < 0) continue;
                char c = (char)v;
                if (c == '\n') continue;
                if (c == '\r')
                {
                    string line = sb.ToString().Trim();
                    sb.Length = 0;
                    if (line.Length == 0) continue;
                    if (line == "OK" || line.StartsWith("ERROR") || line == "VCON" || line.Contains("NO CARRIER") || line.Contains("BUSY") || line.Contains("NO DIALTONE") || line.Contains("NO ANSWER"))
                        return line;
                }
                else sb.Append(c);
            }
            else Thread.Sleep(3);
        }
        return sb.ToString().Trim();
    }

    public static string Capture(string port, int baud, int voiceFormat, string number, int seconds, string outFile, out int byteCount)
    {
        byteCount = 0;
        var log = new StringBuilder();
        sp = new SerialPort(port, baud, Parity.None, 8, StopBits.One);
        sp.ReadTimeout = 500;
        sp.WriteTimeout = 1500;
        sp.DtrEnable = true;
        sp.RtsEnable = true;
        sp.Handshake = Handshake.RequestToSendXOnXOff;
        sp.ReadBufferSize = 1 << 16;
        sp.Open();
        Thread.Sleep(400);
        try
        {
            log.AppendLine("ATZ=" + Cmd("ATZ", 3000));
            log.AppendLine("FCLASS8=" + Cmd("AT+FCLASS=8", 2000));
            log.AppendLine("VSM=" + Cmd("AT+VSM=" + voiceFormat, 2500));
            log.AppendLine("VLS0=" + Cmd("AT+VLS=0", 2000));
            log.AppendLine("DIAL=" + Cmd("ATD" + number, 25000));
            log.AppendLine("VLS1=" + Cmd("AT+VLS=1", 2500));

            // start voice receive; the modem answers (OK/VCON) then streams
            try { sp.DiscardInBuffer(); } catch { }
            sp.Write("AT+VRX\r");
            // skip the response line(s)
            DateTime hdrEnd = DateTime.Now.AddMilliseconds(1500);
            while (DateTime.Now < hdrEnd)
            {
                if (sp.BytesToRead > 0) { sp.ReadByte(); }
                else
                {
                    if (hdrEnd.Subtract(DateTime.Now).TotalMilliseconds < 1200) break;
                    Thread.Sleep(2);
                }
            }

            var ms = new MemoryStream();
            byte[] tmp = new byte[8192];
            DateTime end = DateTime.Now.AddSeconds(seconds);
            while (DateTime.Now < end)
            {
                int avail = sp.BytesToRead;
                if (avail > 0)
                {
                    int want = Math.Min(avail, tmp.Length);
                    int got = sp.Read(tmp, 0, want);
                    if (got > 0) ms.Write(tmp, 0, got);
                }
                else Thread.Sleep(2);
            }
            byteCount = (int)ms.Length;
            File.WriteAllBytes(outFile, ms.ToArray());

            // stop recording
            byte[] dle = new byte[] { 0x10, 0x03 };
            sp.Write(dle, 0, dle.Length);
            Thread.Sleep(600);
            Cmd("AT", 1500);
            log.AppendLine("ATH=" + Cmd("ATH", 2000));
            log.AppendLine("FCLASS0=" + Cmd("AT+FCLASS=0", 2000));
            log.AppendLine("ATZ2=" + Cmd("ATZ", 2000));
        }
        catch (Exception ex)
        {
            log.AppendLine("EXC=" + ex.Message);
        }
        finally
        {
            try { sp.Close(); } catch { }
            try { sp.Dispose(); } catch { }
        }
        return log.ToString() + "BYTES=" + byteCount;
    }
}
