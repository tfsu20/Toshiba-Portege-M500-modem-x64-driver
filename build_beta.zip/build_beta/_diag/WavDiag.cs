using System;
using System.IO;
using System.Text;

public static class WavDiag
{
    static short[] ReadWav(string path, out int rate)
    {
        byte[] b = File.ReadAllBytes(path);
        rate = 11025;
        int pos = 12, dataOff = -1, dataLen = 0;
        while (pos + 8 <= b.Length)
        {
            string id = Encoding.ASCII.GetString(b, pos, 4);
            int len = BitConverter.ToInt32(b, pos + 4);
            if (id == "fmt ")
            {
                rate = BitConverter.ToInt32(b, pos + 12);
            }
            else if (id == "data") { dataOff = pos + 8; dataLen = len; break; }
            pos += 8 + len + (len & 1);
        }
        if (dataOff < 0) { dataOff = 44; dataLen = b.Length - 44; }
        int n = dataLen / 2;
        short[] s = new short[n];
        for (int i = 0; i < n; i++) s[i] = BitConverter.ToInt16(b, dataOff + i * 2);
        return s;
    }

    static double Goertzel(short[] x, int off, int len, double f, double rate)
    {
        double w = 2 * Math.PI * f / rate, c = 2 * Math.Cos(w), s0 = 0, s1 = 0, s2 = 0;
        for (int i = 0; i < len; i++) { s0 = x[off + i] + c * s1 - s2; s2 = s1; s1 = s0; }
        return Math.Sqrt(Math.Abs(s1 * s1 + s2 * s2 - c * s1 * s2)) / Math.Max(1, len);
    }

    public static string Analyze(string path)
    {
        int rate;
        short[] x = ReadWav(path, out rate);
        var r = new StringBuilder();
        r.AppendLine("file=" + Path.GetFileName(path) + "  samples=" + x.Length + "  headerRate=" + rate + "  dur=" + (x.Length / (double)rate).ToString("F2") + " s");

        // use the true measured rate for analysis
        double fs = 10000.0;
        int frame = (int)(fs * 0.020);           // 20 ms

        int nf = x.Length / frame;
        double[] rms = new double[nf];
        for (int f = 0; f < nf; f++)
        {
            double s = 0;
            for (int i = 0; i < frame; i++) { double v = x[f * frame + i]; s += v * v; }
            rms[f] = Math.Sqrt(s / frame);
        }
        double maxR = 0; foreach (double v in rms) if (v > maxR) maxR = v;
        double thr = Math.Max(120.0, maxR * 0.25);
        r.AppendLine("frame=20ms frames=" + nf + " maxFrameRMS=" + maxR.ToString("F0") + " activeThr=" + thr.ToString("F0"));

        // segment into bursts
        int i2 = 0, bursts = 0, actFrames = 0;
        var lens = new System.Collections.Generic.List<int>();
        var gapsInBurst = new System.Collections.Generic.List<int>();
        while (i2 < nf)
        {
            while (i2 < nf && rms[i2] < thr) i2++;
            if (i2 >= nf) break;
            int st = i2; while (i2 < nf && rms[i2] >= thr) i2++;
            bursts++; actFrames += i2 - st;
            lens.Add(i2 - st);
            // internal gaps: any 20 ms frame inside the burst below thr*0.15 (look ahead within burst only)
        }
        r.AppendLine("bursts=" + bursts + "  activeFrames=" + actFrames + " (" + (100.0 * actFrames / Math.Max(1, nf)).ToString("F1") + "%)");
        if (lens.Count > 0)
        {
            double sum = 0; int mn = int.MaxValue, mx = 0;
            foreach (int L in lens) { sum += L; if (L < mn) mn = L; if (L > mx) mx = L; }
            r.AppendLine("  burst len ms: avg=" + (sum / lens.Count * 20).ToString("F0") + " min=" + (mn * 20) + " max=" + (mx * 20));
            r.AppendLine("  burst lengths(ms): " + string.Join(",", lens.GetRange(0, Math.Min(10, lens.Count)).ConvertAll(v => (v * 20).ToString()).ToArray()));
        }

        // click detection over the whole file: large sample-to-sample step + sign change
        int clicks = 0; int lastClick = -1;
        var clickGaps = new System.Collections.Generic.List<int>();
        for (int i = 1; i < x.Length; i++)
        {
            int d = x[i] - x[i - 1];
            if (Math.Abs(d) > 7000 && ((x[i] > 0) != (x[i - 1] > 0)))
            {
                clicks++;
                if (lastClick >= 0) clickGaps.Add(i - lastClick);
                lastClick = i;
            }
        }
        r.AppendLine("hard-step/sign-flip events (clicks)=" + clicks + "  (" + (clicks / (x.Length / fs)).ToString("F1") + "/s)");
        if (clickGaps.Count > 5)
        {
            clickGaps.Sort();
            r.AppendLine("  click spacing ms: median=" + (clickGaps[clickGaps.Count / 2] / fs * 1000).ToString("F1") + " min=" + (clickGaps[0] / fs * 1000).ToString("F1"));
        }

        // purity of the dominant tone inside the longest burst
        int bestSt = 0, bestLen = 0;
        for (int f = 0; f < nf; f++)
        {
            if (rms[f] < thr) continue;
            int st = f; while (f < nf && rms[f] >= thr) f++;
            if (f - st > bestLen) { bestLen = f - st; bestSt = st; }
        }
        if (bestLen > 5)
        {
            int off = bestSt * frame, len = Math.Min(bestLen * frame, x.Length - off);
            double bestM = 0, bestF = 0;
            for (double f = 300; f <= 600; f += 5) { double m = Goertzel(x, off, len, f, fs); if (m > bestM) { bestM = m; bestF = f; } }
            double total = 0; for (int i = 0; i < len; i++) { double v = x[off + i]; total += v * v; }
            double rmsBurst = Math.Sqrt(total / len);
            r.AppendLine("longest burst: " + (len / fs * 1000).ToString("F0") + " ms, RMS=" + rmsBurst.ToString("F0") + ", dominant=" + bestF.ToString("F0") + " Hz (Goertzel=" + bestM.ToString("F0") + ", sine-equivalent RMS=" + (bestM * 1.414).ToString("F0") + ")");
            r.AppendLine("  purity = toneRMS/burstRMS = " + (bestM * 1.414 / Math.Max(1, rmsBurst)).ToString("F2"));
        }
        return r.ToString();
    }
}
