using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Threading;

public static class VoiceDiag
{
    static SerialPort sp;

    static string Cmd(string c, int ms)
    {
        try { sp.DiscardInBuffer(); } catch { }
        sp.Write(c + "\r");
        var sb = new StringBuilder();
        DateTime end = DateTime.Now.AddMilliseconds(ms);
        while (DateTime.Now < end)
        {
            if (sp.BytesToRead > 0)
            {
                int v = sp.ReadByte(); if (v < 0) continue;
                char ch = (char)v;
                if (ch == '\r') { string l = sb.ToString().Trim(); sb.Length = 0; if (l.Length > 0 && !l.StartsWith("AT")) return l; }
                else if (ch != '\n') sb.Append(ch);
            }
            else Thread.Sleep(2);
        }
        return sb.ToString().Trim();
    }

    static short ALawToPcm(byte a)
    {
        a ^= 0x55;
        int v = (a & 0x0F) << 4;
        int seg = (a & 0x70) >> 4;
        if (seg == 0) v += 8;
        else if (seg == 1) v += 0x108;
        else { v += 0x108; v <<= (seg - 1); }
        return (short)(((a & 0x80) != 0) ? v : -v);
    }

    // Goertzel magnitude at frequency f, assuming sample rate rate
    static double Goertzel(double[] x, double f, double rate)
    {
        double w = 2 * Math.PI * f / rate;
        double c = 2 * Math.Cos(w), s0 = 0, s1 = 0, s2 = 0;
        for (int i = 0; i < x.Length; i++) { s0 = x[i] + c * s1 - s2; s2 = s1; s1 = s0; }
        return Math.Sqrt(s1 * s1 + s2 * s2 - c * s1 * s2) / Math.Max(1, x.Length);
    }

    public static int Run(string port, string number, int seconds, string outRaw, out string report)
    {
        var r = new StringBuilder();
        sp = new SerialPort(port, 115200, Parity.None, 8, StopBits.One);
        sp.ReadTimeout = 600; sp.WriteTimeout = 1500;
        sp.DtrEnable = true; sp.RtsEnable = true; sp.Handshake = Handshake.None;
        sp.ReadBufferSize = 1 << 16;
        sp.Open();
        Thread.Sleep(400);
        r.AppendLine("ATZ=" + Cmd("ATZ", 2500));
        r.AppendLine("FCLASS8=" + Cmd("AT+FCLASS=8", 1500));
        r.AppendLine("VSM5=" + Cmd("AT+VSM=5", 1500));
        r.AppendLine("VLS0=" + Cmd("AT+VLS=0", 1500));
        r.AppendLine("DIAL=" + Cmd("ATD" + number, 20000));
        r.AppendLine("VLS1=" + Cmd("AT+VLS=1", 2000));

        try { sp.DiscardInBuffer(); } catch { }
        sp.Write("AT+VRX\r");
        Thread.Sleep(250);
        try { sp.DiscardInBuffer(); } catch { }

        var raw = new List<byte>(262144);
        var sw = Stopwatch.StartNew();
        byte[] tmp = new byte[16384];
        while (sw.Elapsed.TotalSeconds < seconds)
        {
            int avail = sp.BytesToRead;
            if (avail > 0)
            {
                int got = sp.Read(tmp, 0, Math.Min(avail, tmp.Length));
                for (int i = 0; i < got; i++) raw.Add(tmp[i]);
            }
            else Thread.Sleep(2);
        }
        double secs = sw.Elapsed.TotalSeconds;
        r.AppendLine("captured=" + raw.Count + " bytes in " + secs.ToString("F2") + " s  => " + (raw.Count / secs).ToString("F0") + " B/s raw");

        byte[] dle = new byte[] { 0x10, 0x03 };
        sp.Write(dle, 0, 2);
        Thread.Sleep(500);
        Cmd("ATH", 2000);
        Cmd("AT+FCLASS=0", 1500);
        Cmd("ATZ", 2000);
        try { sp.Close(); } catch { }

        // unescape: <DLE><DLE> -> <DLE>
        var un = new List<byte>(raw.Count);
        bool esc = false;
        int dropped = 0;
        foreach (byte b in raw)
        {
            if (esc) { esc = false; if (b == 0x03) { dropped++; } else un.Add(b); }
            else if (b == 0x10) esc = true;
            else un.Add(b);
        }
        byte[] a = un.ToArray();
        File.WriteAllBytes(outRaw, a);
        r.AppendLine("unescaped=" + a.Length + " bytes  (" + (a.Length / secs).ToString("F0") + " B/s)  DLE removed=" + (raw.Count - a.Length));

        // PCM
        double[] pcm = new double[a.Length];
        for (int i = 0; i < a.Length; i++) pcm[i] = ALawToPcm(a[i]);

        // overall level
        double sum = 0, peak = 0;
        foreach (double v in pcm) { sum += v * v; double t = Math.Abs(v); if (t > peak) peak = t; }
        r.AppendLine("RMS=" + Math.Sqrt(sum / Math.Max(1, pcm.Length)).ToString("F0") + "  peak=" + peak.ToString("F0"));

        // pitch search 300..800 Hz, reported for both candidate sample rates
        foreach (double rate in new double[] { 8000, 11025, 12000 })
        {
            double best = 0, bf = 0;
            for (double f = 300; f <= 800; f += 5)
            {
                double m = Goertzel(pcm, f, rate);
                if (m > best) { best = m; bf = f; }
            }
            // where does a real 450 Hz tone land if the true rate were 'rate'?
            double mapped = 450.0 * 8000.0 / rate;
            r.AppendLine("if rate=" + rate + " -> peak tone at " + bf.ToString("F0") + " Hz (a true 450 Hz tone would appear at " + mapped.ToString("F0") + " Hz)");
        }

        // envelope / gap analysis at 11025 (20 ms frames)
        int frame = 220; int gaps = 0; int longest = 0; int run = 0; double minRms = double.MaxValue;
        double[] env = new double[pcm.Length / frame + 1];
        int fi = 0;
        for (int i = 0; i + frame <= pcm.Length; i += frame)
        {
            double s2 = 0;
            for (int j = 0; j < frame; j++) { double v = pcm[i + j]; s2 += v * v; }
            double fr = Math.Sqrt(s2 / frame);
            env[fi++] = fr;
            if (fr < minRms) minRms = fr;
            if (fr < 200) { run++; if (run > longest) longest = run; gaps++; }
            else run = 0;
        }
        r.AppendLine("frames=" + fi + "  near-silent frames=" + gaps + " (" + (100.0 * gaps / Math.Max(1, fi)).ToString("F1") + "%)  longest silent run=" + (longest * 20) + " ms  min frame RMS=" + minRms.ToString("F0"));

        // write 16-bit PCM WAV at 11025 for offline listening
        string wav = Path.ChangeExtension(outRaw, ".wav");
        using (var fs = new FileStream(wav, FileMode.Create))
        using (var bw = new BinaryWriter(fs))
        {
            int dataLen = pcm.Length * 2;
            bw.Write(Encoding.ASCII.GetBytes("RIFF")); bw.Write(36 + dataLen); bw.Write(Encoding.ASCII.GetBytes("WAVE"));
            bw.Write(Encoding.ASCII.GetBytes("fmt ")); bw.Write(16); bw.Write((short)1); bw.Write((short)1);
            bw.Write(11025); bw.Write(11025 * 2); bw.Write((short)2); bw.Write((short)16);
            bw.Write(Encoding.ASCII.GetBytes("data")); bw.Write(dataLen);
            foreach (double v in pcm) { int s = (int)v; if (s > 32767) s = 32767; if (s < -32768) s = -32768; bw.Write((short)s); }
        }
        r.AppendLine("wav=" + wav);
        report = r.ToString();
        return 0;
    }
}
